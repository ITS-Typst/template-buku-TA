#let fn(
  info-id: (),
  info-en: (),
  author: (),
  supervisor: (),
  date: datetime(year: 2023, month: 6, day: 24),
) = [
  #heading(numbering: none)[PEDOMAN PENGGUNAAN TESIS]

  Tesis Magister yang tidak dipublikasikan terdaftar dan tersedia di Perpustakaan Institut Teknologi Bandung, dan terbuka untuk umum dengan ketentuan bahwa hak cipta ada pada penulis dengan mengikuti aturan HaKI yang berlaku di Institut Teknologi Bandung.
  Referensi kepustakaan diperkenankan dicatat, tetapi pengutipan atau peringkasan hanya dapat dilakukan seizin penulis dan harus disertai dengan kaidah ilmiah untuk menyebutkan sumbernya.

  Sitasi hasil penelitian Tesis ini dapat di tulis dalam bahasa Indonesia sebagai berikut:

  #par(hanging-indent: 3em)[
    #author.last-name, #{ author.first-name }. (#date.display("[year]")): #info-id.title-content, Tesis Program Magister, Institut Teknologi Bandung.
  ]

  dan dalam Bahasa Inggris sebagai berikut:

  #par(hanging-indent: 3em)[
    #author.last-name, #{ author.first-name }. (#date.display("[year]")): _#{ info-en.title }_, Master's Thesis, Institut Teknologi Bandung.
  ]

  Memperbanyak atau menerbitkan sebagian atau seluruh tesis haruslah seizin Dekan Sekolah Pascasarjana, Institut Teknologi Bandung.
]
