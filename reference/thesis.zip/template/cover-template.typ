#import "./utils.typ": *

#let fn(
  title-content: [],
  author-name: [],
  student-nim: [],
  major-name: [],
  date: datetime(year: 2023, month: 6, day: 24),
  draft-body: none,
) = [
  #set align(center)
  #set par(justify: false, leading: 0.5em)

  #heading(numbering: none, outlined: false)[#upper(title-content)]

  #set text(weight: "bold")

  #text(size: 14pt)[TESIS]

  Karya tulis sebagai salah satu syarat \
  untuk memperoleh gelar Magister dari \
  Institut Teknologi Bandung

  #v(1fr)

  Oleh \
  #text(size: 14pt)[
    #upper(author-name) \
    NIM: #student-nim \
    (#major-name)
  ]

  #v(1fr)

  #image("images/cover-ganesha.jpg", width: 15%)

  #v(2fr)

  #text(size: 14pt)[
    INSTITUT TEKNOLOGI BANDUNG \
    #upper(get-month-name(date.month())) #date.display("[year]")
  ]

]
