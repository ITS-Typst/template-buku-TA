#import "/lib/phantom.typ": phantom

#let fn(body) = [
#set align(center)

#phantom[#heading(numbering: none)[HALAMAN PERUNTUKAN]]

#v(1fr)

_#{body}_

#v(1fr)
]