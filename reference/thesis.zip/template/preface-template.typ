#let fn(
  content: [],
) = [
#heading(numbering: none)[KATA PENGANTAR]

#content
]
