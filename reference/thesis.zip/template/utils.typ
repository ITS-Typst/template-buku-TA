#let get-month-name(month) = (
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
).at(month - 1)

#let numbering-kind(kind) = num => {
  let hh = query(selector(heading.where(level: 1)).before(here()))
  let bef = 0
  if hh.len() > 0 {
    let h = hh.last()
    let figs = query(selector(figure.where(kind: kind)).before(h.location()))
    bef = figs.len()
  }
  let num2 = num - bef
  numbering("I.1", counter(heading).at(here()).first(), if num2 > 0 { num2 } else { 0 })
}

#let fig-img(img, caption: none) = {
  figure(
    img,
    kind: "gambar",
    supplement: "Gambar",
    caption: caption,
    numbering: numbering-kind("gambar"),
    placement: auto,
  )
}

#let fig-tab(tab, caption: none) = {
  set figure.caption(position: top)
  figure(
    tab,
    kind: "tabel",
    supplement: "Tabel",
    caption: caption,
    numbering: numbering-kind("tabel"),
    placement: auto,
  )
}

#let fig-code(body, caption: none) = {
  figure(
    {
      set text(size: 10pt)
      set par(justify: false, leading: 0.5em)
      block(outset: 4pt, stroke: black, align(left)[#body])
    },
    kind: "kode",
    supplement: "Kode",
    caption: caption,
    numbering: numbering-kind("kode"),
    placement: auto,
  )
}

#let fig-eq(img) = {
  figure(img, kind: "persamaan", supplement: "Persamaan", numbering: numbering-kind("persamaan"))
}
