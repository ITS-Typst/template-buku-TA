#let fn(
  heading-text: [],
  title-content: [],
  by-text: [],
  author-name: [],
  student-nim: [],
  major-name: [],
  body,
  term-text: [],
  terms: (),
) = [
#set align(center)
#set par(justify: false, leading: 0.5em)
#set text(weight: "bold")

#heading(numbering: none)[#heading-text]

#text(size:14pt)[#upper(title-content)]

#v(2em)

#text(weight: "regular")[#by-text] \
#text(size: 14pt)[
  #author-name \
  NIM: #student-nim \
  (#major-name)
]

#v(2em)

#set text(weight: "regular")
#set align(left)
#set par(justify: true)
#body

#{term-text}: #terms.join(", ")

]