#import "/lib/phantom.typ": phantom
#import "./utils.typ": *

#let fn(
  title-content: [],
  author-name: [],
  student-nim: [],
  major-name: [],
  supervisor: (),
  date: datetime(year: 2023, month: 6, day: 24),
) = [
  #set align(center)
  #set par(justify: false, leading: 0.5em)
  #set text(weight: "bold")

  #phantom[#heading(numbering: none)[HALAMAN PENGESAHAN]]

  #text(size: 14pt)[#upper(title-content)]

  #v(2em)

  #text(weight: "regular")[Oleh] \
  #text(size: 14pt)[
    #author-name \
    NIM: #student-nim \
    (#major-name)
  ]

  #v(1em)

  #set text(weight: "regular")

  Institut Teknologi Bandung

  #v(3em)

  Menyetujui \
  Tim Pembimbing

  Tanggal #date.day() #get-month-name(date.month()) #date.display("[year]")

  #v(1em)

  Ketua

  #box[
    #place(center + bottom, dy: 1em, image("../sign_masayu.png", height: 6em))
    #v(4em)
  ]

  (#supervisor.name) \
  NIP: #supervisor.nip

]
