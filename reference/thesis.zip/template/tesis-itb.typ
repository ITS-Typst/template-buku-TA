#import "cover-template.typ"
#import "abstract-template.typ"
#import "agreement-template.typ"
#import "guidelines-template.typ"
#import "dedication-template.typ"
#import "preface-template.typ"
#import "/lib/glossary.typ"
#import "/lib/phantom.typ": phantom

// #let tab-counter = counter("tab-counter")

#let template(
  info-id: (),
  // (
  //   date: (date: number, month: string, year: string),
  //   title: string,
  //   title-content: [],
  //   major-name: string,
  //   abstract: (body: [], terms: ())
  // )
  info-en: (),
  // (
  //   date: (date: number, month: string, year: string),
  //   title: string,
  //   major-name: string,
  //   abstract: (body: [], terms: ())
  // )
  author: (), // (first-name: string, last-name: string, nim: string)
  supervisor: (), // (name: string, nip: string)
  preface: (), // (title: string) => []
  dedication: [], // string
  glossary-content: [],
  body, // []
  bibliography-file: none, // string
  appendix: none, // []
  draft-body: none,
  terms-body: none,
  date: datetime(year: 2023, month: 6, day: 24),
) = {
  // ~ CONFIGURATIONS
  let author-name = author.first-name + " " + author.last-name
  set document(title: info-id.title, author: author-name)
  set page(paper: "a4", margin: (
    left: 4cm,
    right: 3cm,
    y: 3cm,
  ))
  set par(justify: true, leading: 1em, linebreaks: "simple")
  set text(font: "Times New Roman", size: 12pt, fallback: false, hyphenate: false)
  set enum(indent: 1em, spacing: 1.5em, tight: false)
  set block(below: 1.5em)
  set heading(numbering: (num1, ..nums) => {
    let arr = nums.pos()
    if arr.len() == 0 {
      "Bab " + numbering("I", num1) + "\t"
    } else {
      numbering("I.1", num1, ..nums)
    }
  })
  // show figure.where(kind: "tabel"): it => {
  //   let name = none
  //   if not it.caption == none {
  //     name = [ #it.caption]
  //   } else {
  //     name = []
  //   }

  //   let title = none
  //   if not it.supplement == none {
  //     title = it.supplement
  //     if not it.numbering == none {
  //       title += " " + it.counter.display(it.numbering)
  //     }
  //   }
  //   set align(center)
  //   block(breakable: false)[
  //     #title#name
  //     #it.body
  //     #v(0.5em)
  //   ]
  // }
  show figure.where(kind: "persamaan"): it => {
    let name = none
    if not it.caption == none {
      name = [ #it.caption]
    } else {
      name = []
    }

    let title = none
    if not it.numbering == none {
      title = [(#it.counter.display(it.numbering))]
    }
    set align(center)
    block(breakable: false, width: 100%)[
      #align(center)[#it.body]#place(top + right)[#title#name]
    ]
  }

  show heading: it => {
    if it.level == 1 {
      set align(center)
      set text(size: 14pt, weight: "bold")
      if it.numbering != none {
        counter(heading).display()
        h(10pt, weak: true)
      }
      it.body
      v(1.5em, weak: true)
      linebreak()
    } else {
      set align(left)
      set text(size: 12pt, weight: "bold")
      if it.numbering != none {
        counter(heading).display()
        h(7pt, weak: true)
      }
      it.body
      v(1.5em, weak: true)
    }
  }

  let outline-entry-fn(prefix-count, start-level: 1) = it => {
    let loc = it.element.location()
    let num = numbering(loc.page-numbering(), ..counter(page).at(loc))
    let body = it.element.body
    let children = body.at("children", default: ())
    let prefixed = children.len() > 1
    if prefixed {
      body = children.slice(1 + prefix-count).join()
      children = body.at("children", default: ())
    }
    link(loc, box(grid(
      columns: 3,
      row-gutter: 0pt,
      {
        for _ in range(it.level - start-level) {
          box(width: 1em)
        }
        if prefixed {
          children.slice(0, 1 + prefix-count).join()
          h(4pt)
        }
      },
      [#body#box(width: 1fr)[#it.fill]],
      align(bottom)[#num],
    )))
  }

  // ~ START CONTENT
  show: glossary.wrapper.with(indent-defs: true)

  //! A hacky way to register all the glossaries first.
  phantom[#glossary-content]

  cover-template.fn(
    title-content: info-id.title-content,
    author-name: author-name,
    student-nim: author.nim,
    major-name: info-id.major-name,
    date: date,
    draft-body: draft-body,
  )
  pagebreak()

  set page(numbering: "i")
  counter(page).update(1)

  abstract-template.fn(
    heading-text: [ABSTRAK],
    title-content: info-id.title-content,
    by-text: [Oleh],
    author-name: author-name,
    student-nim: author.nim,
    major-name: info-id.major-name,
    term-text: [Kata kunci],
    terms: info-id.abstract.terms,
  )[#info-id.abstract.body]
  pagebreak()

  abstract-template.fn(
    heading-text: [_ABSTRACT_],
    title-content: [_#{ info-en.title }_],
    by-text: [_By_],
    author-name: author-name,
    student-nim: author.nim,
    major-name: [_#{ info-en.major-name }_],
    term-text: [_Keywords_],
    terms: info-en.abstract.terms,
  )[_#(info-en.abstract.body) _]
  pagebreak()

  agreement-template.fn(
    title-content: info-id.title-content,
    author-name: author-name,
    student-nim: author.nim,
    major-name: info-id.major-name,
    supervisor: supervisor,
    date: date,
  )
  pagebreak()

  guidelines-template.fn(
    author: author,
    supervisor: supervisor,
    info-id: info-id,
    info-en: info-en,
    date: date,
  )
  pagebreak()

  dedication-template.fn(dedication)
  pagebreak()

  preface-template.fn(content: preface.fn(title: info-id.title-content))
  pagebreak()

  context {
    // show outline.entry: outline-entry-fn(1)

    heading(numbering: none)[DAFTAR ISI]
    {
      outline(title: none, depth: 4, target: selector(heading).before(
        query(<lampiran>).last().location(),
        inclusive: true,
      ))
    }
    pagebreak()

    if appendix != none {
      heading(numbering: none)[DAFTAR LAMPIRAN]
      {
        // show outline.entry: outline-entry-fn(1, start-level: 2)
        outline(title: none, depth: 4, target: selector(heading).after(query(<lampiran>).last().location()))
      }
      pagebreak()
    }
  }

  {
    // show outline.entry: outline-entry-fn(3)

    heading(numbering: none)[DAFTAR GAMBAR]
    outline(title: none, depth: 4, target: figure.where(kind: "gambar"))
    pagebreak()

    heading(numbering: none)[DAFTAR TABEL]
    outline(
      title: none,
      target: figure.where(kind: "tabel"),
      // target: heading.where(level: 71),
    )
    pagebreak()

    heading(numbering: none)[DAFTAR KODE]
    outline(title: none, depth: 4, target: figure.where(kind: "kode"))
    pagebreak()
  }

  heading(numbering: none)[DAFTAR SINGKATAN DAN LAMBANG]
  [#glossary-content]
  pagebreak()

  if terms-body != none {
    heading(numbering: none)[DAFTAR ISTILAH]
    [#terms-body]
    pagebreak()
  }

  set page(numbering: "1")
  counter(page).update(1)

  body
  pagebreak()

  bibliography(bibliography-file, title: [DAFTAR PUSTAKA], style: "apa")

  if appendix != none {
    pagebreak()
    v(1fr)
    {
      set align(center)
      set text(size: 14pt, weight: "bold")
      heading(numbering: none)[LAMPIRAN <lampiran>]
    }
    v(1fr)
    pagebreak()

    counter(heading).update(1)

    set heading(supplement: "Lampiran", numbering: (num1, ..nums) => {
      let arr = nums.pos()
      if arr.len() == 0 {
        []
      } else if arr.len() == 1 {
        [Lampiran #numbering("A.1", ..arr)] + "\t"
      } else {
        numbering("A.1", ..arr)
      }
    })

    appendix
  }
}
