#let phantom(body) = {
  place(top, scale(x: 0%, y: 0%, hide(body)))
}
