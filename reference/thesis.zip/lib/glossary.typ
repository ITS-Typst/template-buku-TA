#import "phantom.typ": phantom

// Glossary code by Hugo Cartigny (BlueskyFR) 🍉

#let GLOSSARY_HEADING_LEVEL = 99

#let upper-prefix = "_"
#let long-suffix = "_"

#let glossary-upper-map = state("glossary-upper-map", (:))

#let register-upper(term: (), content: []) = {
  glossary-upper-map.update(v => {
    v.insert(term, content)
    v
  })
}

#let wrapper(indent-defs: false, doc) = {
  // ✨ The glossary displays its items using level GLOSSARY_HEADING_LEVEL headings
  let glossary = state("glossary", (:))

  // Hide the numbering for level GLOSSARY_HEADING_LEVEL titles
  show heading.where(level: GLOSSARY_HEADING_LEVEL): it => text(weight: "regular", it.body)

  let page-refs-color = rgb("#7630EA")

  show terms: list => {
    let terms-grid = ()
    // Add terms to glossary
    for item in list.children {
      glossary.update(v => {
        v.insert(item.term.text, (
          // Holds the list of the locations referencing the term
          ref-locs: (),
          // The actual term definition
          def: item.description,
        ))

        // Return the new state with the added entry
        v
      })

      if indent-defs {
        // Term
        terms-grid.push([
          #heading(level: GLOSSARY_HEADING_LEVEL, numbering: "1")[*#item.term*]
          #label(item.term.text)
          #heading(level: GLOSSARY_HEADING_LEVEL, numbering: none)[#phantom[*#item.term*]]
          #label(upper-prefix + item.term.text)
          #heading(level: GLOSSARY_HEADING_LEVEL, numbering: none)[#phantom[*#item.term*]]
          #label(item.term.text + long-suffix)
          #heading(level: GLOSSARY_HEADING_LEVEL, numbering: none)[#phantom[*#item.term*]]
          #label(upper-prefix + item.term.text + long-suffix)
        ])

        // Definition
        terms-grid.push([
          #item.description
        ])

        terms-grid.push([
          // Pages where the term is referenced
          #show: text.with(page-refs-color)
          #context {
            let arr = glossary.final().at(item.term.text).ref-locs.map(l => {
              let page-number = counter(page).at(l).first()
              link(l, str(page-number))
            })
            // .join(", ")
            if arr.len() > 0 { arr.first() }
          })
        ])
      } else {
        // Display items directly one by one since
        // we don't need to build a grid

        // Use a level GLOSSARY_HEADING_LEVEL title so it doesn't conflict with regular ones
        // and it can be refered to by @citations
        heading(level: GLOSSARY_HEADING_LEVEL, numbering: "1")[
          *#item.term*:~~#item.description
          // Pages where the term is referenced
          #show: text.with(page-refs-color)
          #locate(loc => {
            glossary
              .final(loc)
              .at(item.term.text)
              .ref-locs
              .map(l => {
                let page-number = counter(page).at(l).first()
                link(l, str(page-number))
              })
              .join(", ")
          })
        ]
        label(item.term.text)
        phantom[#heading(level: GLOSSARY_HEADING_LEVEL, numbering: none)[*#item.term*]]
        label(upper-prefix + item.term.text)[ \ ]
      }
    }

    if indent-defs {
      grid(
        columns: (1fr, 4fr, 0.25fr),
        column-gutter: 2mm,
        row-gutter: 8mm,
        ..terms-grid
      )
    }

    // 🐛 Debug
    //glossary.display()
  }

  show ref: r => {
    // Search for the source of the ref
    let term = str(r.target)
    let capitalize = false
    let long = false
    if term.starts-with(upper-prefix) {
      term = term.slice(1)
      capitalize = true
    }
    if term.ends-with(long-suffix) {
      term = term.slice(0, term.len() - 1)
      long = true
    }
    let loc = here()
    let res = query(r.target)

    // If the source exists and is the glossary (heading level GLOSSARY_HEADING_LEVEL)
    if res.len() > 0 and res.first().has("level") and res.first().level == GLOSSARY_HEADING_LEVEL {
      let entry = glossary.at(loc).at(term, default: none)

      if entry == none {
        panic("term " + term + " not found. current glossary: " + repr(glossary.at(loc)))
      }

      // Replace term by the user-specified supplement if not none
      let custom-term = {
        if r.citation.supplement != none { r.citation.supplement } else { term }
      }

      // If it is the first reference to the term, display its definition too
      // link(res.first().location(), {
      //   if entry.ref-locs.len() == 0 {
      //     let long-def = entry.def
      //     let upper-map = glossary-upper-map.at(loc)
      //     if capitalize and term in upper-map {
      //       long-def = upper-map.at(term)
      //     }
      //     [#long-def (#custom-term)]
      //   }
      //   else [#custom-term]
      // })
      if entry.ref-locs.len() == 0 or long {
        let long-def = entry.def
        let upper-map = glossary-upper-map.at(loc)
        if capitalize and term in upper-map {
          long-def = upper-map.at(term)
        }
        [#long-def (#custom-term)]
      } else [#custom-term]

      // Add location to the term's ref list if the current page
      // is not already listed
      glossary.update(v => {
        // If this page is not in, push the loc in!
        // if v.keys().contains(term) {
        if v.at(term).ref-locs.all(l => l.position().page != loc.page()) {
          v
            .at(term)
            .ref-locs
            .push(
              // Current page loc
              loc,
            )
        }
        // }
        v
      })
    } // Otherwise just return the ref as it is
  }

  doc
}
