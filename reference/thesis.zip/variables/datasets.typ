#let ds-counts = (
  panl-bppt: 24024,
  iwslt17: 107329,
  amr3-train: 55635,
  amr3-train-augfil: 92867,
  amr3-dev: 1722,
  amr2-test: 1371,
)
#{
  ds-counts.parallel-corpora = ds-counts.panl-bppt + ds-counts.iwslt17
  ds-counts.amr3-train-aug = ds-counts.amr3-train*2
}

#let ds-qualities = (
  amr3-train-aug: (
    cos-sim: 0.799778,
    bleu-back: 44.28519,
  ),
  amr3-train-augfil: (
    cos-sim: 0.881773,
    bleu-back: 45.37009,
  ),
)

#let vocab-counts = (
  mbart-large: 250054,
  mbart-trimmed: 35108,
)
