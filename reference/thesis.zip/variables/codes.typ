#let codes = (
  mbart-trimming: ```python
import json
from transformers import MBartConfig, MBart50Tokenizer, MBartForConditionalGeneration
from hftrim.TokenizerTrimmer import TokenizerTrimmer
from hftrim.ModelTrimmers import MBartTrimmer

data = []
with open('datasets/amrbart/pretrain.jsonl') as f:
    data.extend([json.loads(line)['sent'] for line in f])
with open('datasets/amrbart/train.jsonl') as f:
    data.extend([json.loads(line)['sent'] for line in f])

# load pretrained config, tokenizer and model
model_path = "models/mbart-large-50"
config = MBartConfig.from_pretrained(model_path)
tokenizer = MBart50Tokenizer.from_pretrained(model_path)
model = MBartForConditionalGeneration.from_pretrained(model_path)

# trim tokenizer
print("Pruning Tokenizer...")
tt = TokenizerTrimmer(tokenizer)
tt.make_vocab(data)
tt.make_tokenizer()
tt.trimmed_tokenizer.save_pretrained('mbart-trimmed')

# trim model
print("Pruning Model...")
mt = MBartTrimmer(model, config, tt.trimmed_tokenizer)
mt.make_weights(tt.trimmed_vocab_ids)
mt.make_model()
mt.trimmed_model.save_pretrained('mbart-trimmed')
  ```,
)

#let pytorch-models = (
  mbart-trimmed: ```python
MBartForConditionalGeneration(
  (model): MBartModel(
    (shared): Embedding(35108, 1024, padding_idx=1)
    (encoder): MBartEncoder(
      (embed_tokens): Embedding(35108, 1024, padding_idx=1)
      (embed_positions): MBartLearnedPositionalEmbedding(1026, 1024)
      ...
    )
    (decoder): MBartDecoder(
      (embed_tokens): Embedding(35108, 1024, padding_idx=1)
      (embed_positions): MBartLearnedPositionalEmbedding(1026, 1024)
      ...
    )
  )
  (lm_head): Linear(in_features=1024, out_features=35108, bias=False)
)
  ```,
  mbart-large: ```python
MBartForConditionalGeneration(
  (model): MBartModel(
    (shared): Embedding(250054, 1024, padding_idx=1)
    (encoder): MBartEncoder(
      (embed_tokens): Embedding(250054, 1024, padding_idx=1)
      (embed_positions): MBartLearnedPositionalEmbedding(1026, 1024)
      ...
    )
    (decoder): MBartDecoder(
      (embed_tokens): Embedding(250054, 1024, padding_idx=1)
      (embed_positions): MBartLearnedPositionalEmbedding(1026, 1024)
      ...
    )
  )
  (lm_head): Linear(in_features=1024, out_features=250054, bias=False)
)
  ```,
)