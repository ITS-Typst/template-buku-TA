#import "/lib/glossary.typ": register-upper

/ AMR: _abstract meaning representation_
#register-upper(term: "AMR", content: [_Abstract meaning representation_])

/ stog: _Sequence-to-Graph Transduction_

/ XL-AMR: _Cross-lingual AMR_

/ SMATCH: _Semantic Match_

/ BERT: _Bidirectional Encoder Representations from Transformers_

/ seq2seq: _sequence-to-sequence_
#register-upper(term: "seq2seq", content: [_Sequence-to-sequence_])

/ GPT2: _Generative Pre-trained Transformer 2_

/ PLM: _pretrained language model_
#register-upper(term: "PLM", content: [_Pretrained language model_])

/ LABSE: _Language-agnostic BERT Sentence Embedding_

/ DFS: _depth-first search_
#register-upper(term: "DFS", content: [_Depth-first search_])

/ 1-NN: _1-Nearest Neighbour_

/ XLM: _Cross-lingual Language Model_

/ MLM: _Masked Language Modeling_

/ TLM: _Translation Language Modeling_

/ BLEU: _Bilingual Evaluation Understudy_
