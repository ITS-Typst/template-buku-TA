#import "@preview/tablex:0.0.9": *
#import "template/utils.typ": *
#import "variables/codes.typ": *
#import "variables/datasets.typ": *
#import "variables/evaluations.typ": *
#import "variables/names.typ": *

#let icite(key) = [
  #cite(label(key), form: "prose")
]

#let rawlink(link-str) = link(link-str)[#raw(link-str)]

#let round-fixed-str(num, d) = {
  let res = str(calc.round(num, digits: d))
  let pad = res.split(".")
  let post-len = 0
  if pad.len() < 2 {
    res += "."
  } else {
    post-len = pad.at(1).len()
  }
  pad = d - post-len
  while pad > 0 {
    res += "0"
    pad -= 1
  }
  return res
}

#let print-number(num, splitter: [,], split-num: 3, d: none) = {
  let res = str(num)
  if d != none {
    res = round-fixed-str(num, d)
  }
  let res-split = res.split(".")
  let left = res-split.at(0)
  let right = res-split.at(1, default: none)
  let mod = calc.rem(left.len(), split-num)
  [#left.slice(0, mod)]
  let i = mod
  while i < left.len() {
    if i > 0 {
      splitter
    }
    [#left.slice(i, i + split-num)]
    i += split-num
  }
  if right != none {
    [.#right]
  }
}

#let eval-labels = (
  [Smatch],
  [Unlabeled],
  [No WSD],
  [Non-sense-frames],
  [Wikification],
  [Named Ent.],
  [Negations],
  [IgnoreVars],
  [Concepts],
  [Frames],
  [Reentrancies],
  [SRL],
)

//? `prf` is a short for precision-recall-f1.
#let create-prf-table(values, labels: eval-labels) = {
  let COL = 3
  let res = ([], [*Precision*], [*Recall*], [*F1*])
  for (i, label) in labels.enumerate() {
    res.push(label)
    for j in range(COL) {
      res.push([#round-fixed-str(values.at(i * COL + j), 1)])
    }
  }
  return tablex(
    columns: 4,
    align: (x, y) => if x > 0 or y == 0 { center } else { left },
    ..res,
  )
}

// (
//   title: string,
//   values: array of prf values,
// )
#let create-f1-comparison-table(a, b, labels: eval-labels, col-label: []) = {
  let res = (col-label, [*#a.title*], [*#b.title*], [*Perbedaan*])
  for (i, label) in labels.enumerate() {
    res.push(label)
    let values = (a.values.at(i * 3 + 2), b.values.at(i * 3 + 2))
    let max_v = calc.max(..values)
    let min_v = calc.min(..values)
    for r in values {
      let v = round-fixed-str(r, 1)
      if (r == max_v and min_v != max_v) {
        v = underline[*#v*]
      }
      res.push(v)
    }
    let sel = calc.round(values.at(1) - values.at(0), digits: 1)
    let is_neg = sel < 0
    sel = round-fixed-str(sel, 1)
    sel = if is_neg [#sel] else [+#sel]
    res.push(sel)
  }
  return tablex(
    columns: 4,
    align: (x, y) => if x > 0 or y == 0 { center } else { left },
    ..res,
  )
}

// (
//   title: string,
//   values: array of prf values,
// )
#let create-f1-comparison-table-narrow(a, b, labels: eval-labels, col-label: []) = {
  let res = (col-label, [*#a.title*], [*#b.title*])
  for (i, label) in labels.enumerate() {
    let values = (a.values.at(i * 3 + 2), b.values.at(i * 3 + 2))

    let sel = calc.round(calc.abs(values.at(1) - values.at(0)), digits: 1)
    sel = round-fixed-str(sel, 1)
    let ZERO = round-fixed-str(0, 1)

    res.push(label)
    let max_v = calc.max(..values)
    for r in values {
      let v = round-fixed-str(r, 1)
      if (r == max_v and sel != ZERO) {
        v = [#underline[*#v*] (+#sel)]
      }
      res.push(v)
    }
  }
  return tablex(
    columns: 3,
    align: (x, y) => if x > 0 or y == 0 { center } else { left },
    ..res,
  )
}

#let create-f1-multi-comparison-table(..args, labels: eval-labels, col-label: []) = {
  let array = args.pos()
  let res = (col-label, ..array.map(v => [*#v.title*]))
  for (i, label) in labels.enumerate() {
    res.push(label)
    let values = array.map(v => v.values.at(i * 3 + 2))
    let max_v = calc.max(..values)
    for r in values {
      let v = round-fixed-str(r, 1)
      if (r == max_v) {
        v = underline[*#v*]
      }
      res.push(v)
    }
  }
  return tablex(
    columns: 1 + array.len(),
    // columns: (auto, ..range(array.len()).map(_ => 1fr)),
    align: (x, y) => if x > 0 or y == 0 { center } else { left },
    ..res,
  )
}

#let smatch-diff(values1, values2) = {
  return round-fixed-str(calc.abs(values1.at(2) - values2.at(2)), 1)
}

#let max-diff(values1, values2) = {
  let diffs = ()
  for i in range(12) {
    diffs.push(calc.abs(values1.at(3 * i + 2) - values2.at(3 * i + 2)))
  }
  return round-fixed-str(calc.max(..diffs), 1)
}

#let to-f1(values) = {
  let l = values.len() / 3
  let res = ()
  for i in range(l) {
    res.push(values.at(3 * i + 2))
  }
  return res
}

#let test-labels = ([Smatch], [Unlab.], [NoWSD], [Wiki.], [NER], [Neg.], [Con.], [Frames], [Reent.], [SRL])
#let removed-eval-label-indices = (3, 7)

// (
//   title: string,
//   values: array of test-formatted values,
// )
#let create-test-comparison-table(.._args, labels: test-labels, col-label: [], bold-indices: none, d: 1) = {
  let args = _args.pos()
  let res = (col-label, ..labels.map(v => [*#v*]))

  let max-values = range(labels.len()).map(i => calc.max(..args.map(v => v.values.at(i)).filter(v => v != none)))

  for arg in args {
    res.push(arg.title)
    for (i, v) in arg.values.enumerate() {
      if v == none {
        res.push([-])
      } else {
        let cell = round-fixed-str(v, d)
        if max-values.at(i) == v and (bold-indices == none or i in bold-indices) {
          cell = underline[*#cell*]
        }
        res.push(cell)
      }
    }
  }

  return tablex(
    columns: (auto, ..range(labels.len()).map(_ => 1fr)),
    align: (x, y) => if x > 0 or y == 0 { center } else { left },
    ..res,
  )
}

#let inline-list(..args, last: [dan]) = {
  let values = args.pos()
  let l = values.len()
  if l == 1 {
    values.at(0)
  } else {
    for (i, value) in values.enumerate() {
      [(#{ i + 1 }) #value]
      if i < l - 2 {
        [, ]
      } else if i == l - 2 {
        [, #last ]
      }
    }
  }
}
