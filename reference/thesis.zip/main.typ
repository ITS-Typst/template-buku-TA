#import "/globals.typ": *
#import "template/tesis-itb.typ"
#import "glossary.typ"
#import "sections/preface.typ"
#import "sections/appendix.typ"
#import "sections/abstracts/abstract-id.typ"
#import "sections/abstracts/abstract-en.typ"
#import "sections/terms.typ"

// Graph Pre-training dan Fine-tuning BART untuk Abstract Meaning Representation Lintas Bahasa Indonesia Inggris
#let info-id = (
  title-content: [Pengembangan _Abstract Meaning Representation_ Parser Lintas Bahasa Indonesia-Inggris dengan BART, Konkatenasi Input, dan Augmentasi Data],
  title: "Pengembangan Abstract Meaning Representation Parser Lintas Bahasa Indonesia-Inggris dengan BART, Konkatenasi Input, dan Augmentasi Data",
  major-name: "Program Studi Magister Informatika",
  abstract: abstract-id,
)
// Graph Pre-training and Fine-tuning BART for Cross-Lingual Indonesian-English Abstract Meaning Representation
#let info-en = (
  title: "Abstract Meaning Representation Parser Development for Cross-lingual Indonesian-English with BART, Input Concatenation, and Dataset Augmentation",
  major-name: "Master's Program in Informatics",
  abstract: abstract-en,
)
#let author = (
  first-name: "Moch. Nafkhan",
  last-name: "Alzamzami",
  nim: "23522007",
)
#let supervisor = (
  name: "Dr. Masayu Leylia Khodra, S.T, M.T.",
  nip: "19760429 200812 2 001",
)

#let dedication = "Dipersembahkan kepada orang tua, kakak, serta keluarga besar tercinta yang senantiasa mendukung lahir dan batin."

#show: tesis-itb.template.with(
  info-id: info-id,
  info-en: info-en,
  author: author,
  supervisor: supervisor,
  preface: preface,
  dedication: dedication,
  glossary-content: glossary,
  terms-body: [#terms],
  bibliography-file: "/references.bib",
  appendix: [#appendix],
)

= Pendahuluan <sec-intro>

#include "sections/1/1/latar-belakang.typ"
#include "sections/1/2/masalah-penelitian.typ"
#include "sections/1/3/tujuan.typ"
#include "sections/1/4/hipotesis.typ"
#include "sections/1/5/batasan-masalah.typ"
#include "sections/1/6/metodologi.typ"
#include "sections/1/7/sistematika.typ"

#pagebreak()

= Tinjauan Pustaka <sec-related-works>

#include "sections/2/1/amr.typ"
#include "sections/2/1/1/xl-amr.typ"
#include "sections/2/1/2/smatch.typ"
#include "sections/2/2/language-model.typ"
#include "sections/2/2/1/bart.typ"
#include "sections/2/2/2/xlm.typ"
#include "sections/2/3/bleu.typ"
#include "sections/2/4/penelitian-terkait.typ"
#include "sections/2/4/1/cai2020.typ"
#include "sections/2/4/2/ensemble.typ"
#include "sections/2/4/3/bai2022.typ"
#include "sections/2/4/4/severina2019.typ"
#include "sections/2/4/5/ilmy2020.typ"
#include "sections/2/4/6/putra2022.typ"
#include "sections/2/4/7/srivastava2022.typ"

#pagebreak()

= Analisis Masalah dan Perancangan Solusi <sec-solution>

#include "sections/3/1/analisis-masalah.typ"
#include "sections/3/2/analisis-solusi.typ"
#include "sections/3/3/rancangan-solusi.typ"

#pagebreak()

= Implementasi <sec-implementation>

#include "sections/4/1/lingkungan-implementasi.typ"
#include "sections/4/2/pembangunan-dataset.typ"
#include "sections/4/3/parameter-pelatihan.typ"
#include "sections/4/4/pemangkasan-vocabulary.typ"
#include "sections/4/5/preproses.typ"

#pagebreak()

= Eksperimen dan Pengujian <sec-results>

#include "sections/5/1/eksperimen.typ"
#include "sections/5/2/pengujian.typ"

#pagebreak()

= Kesimpulan dan Saran <sec-conclusions>

#include "sections/6/1/kesimpulan.typ"
#include "sections/6/2/saran.typ"
