#import "/globals.typ": *

== Tujuan

Tujuan tesis ini adalah untuk menghasilkan sebuah model #t.amrparsing lintas bahasa dari kalimat berbahasa Indonesia menjadi @AMR berbahasa Inggris serta melakukan evaluasi kelayakan model tersebut dalam merepresentasikan makna kalimat berbahasa Indonesia dalam bentuk @AMR.
