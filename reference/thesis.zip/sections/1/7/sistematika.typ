#import "/globals.typ": *

== Sistematika Pembahasan

Laporan tesis ini disusun dalam enam bab.
Berikut adalah penjelasan dari masing-masing bab:

+ Bab I Pendahuluan \
  Pendahuluan membahas latar belakang, rumusan masalah, tujuan, hipotesis batasan masalah, serta metodologi yang digunakan pada pengerjaan tesis ini.

+ Bab II Tinjauan Pustaka \
  Tinjauan pustaka membahas konsep dan teori yang digunakan dalam pengerjaan tesis ini serta penelitian-penelitian terkait yang pernah dilakukan sebelumnya yang akan dikembangkan lebih lanjut pada tesis ini.

+ Bab III Analisis Masalah dan Perancangan Solusi \
  Bab ini membahas masalah-masalah yang ada saat ini yang ingin diselesaikan pada tesis ini, menjabarkan alternatif solusi kemudian membahas rancangan solusi yang digunakan untuk menyelesaikan masalah dan mencapai tujuan tesis.

+ Bab IV Implementasi \
  Bab ini berisi penjelasan mengenai implementasi masing-masing proses yang dilakukan sesuai dengan rancangan solusi.

+ Bab V Eksperimen dan Pengujian \
  Eksperimen membahas tujuan, skenario, hasil, serta analisis eksperimen yang dilakukan pada tesis ini.
  Pengujian membahas hasil evaluasi dan analisis dari hasil model pada data uji.

+ Bab VI Kesimpulan dan Saran \
  Bab ini berisi kesimpulan dan saran dari penelitian yang telah dilakukan.
  Saran yang tertera ditunjukkan sebagai masukan untuk pengembangan dari penelitian ini kedepannya.
