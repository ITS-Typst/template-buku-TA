#import "/globals.typ": *

== Hipotesis

#let premise-counter = counter("premise-counter")

#let premise() = context {
  premise-counter.step()
  [*Premis #premise-counter.display():*]
}

#premise() AMR berbahasa Inggris dapat digunakan sebagai representasi kalimat dalam bahasa lain @damonte2018.

#premise() Teknik #t.gpretraining AMRBART oleh #icite("bai2022") yang menggunakan model bahasa BART merupakan teknik yang menghasilkan kinerja #t.amrparsing terbaik berdasarkan metrik @SMATCH.

#premise() Fitur #t.mwordem dan pelatihan pada _silver dataset_ dapat meningkatkan kinerja pembangkit AMR cross-lingual @blloshmi2020.
Dataset pasangan kalimat Bahasa Indonesia dan graf AMR berbahasa Inggris dapat dihasilkan dari dataset pasangan teks berbahasa Inggris dan graf AMR yang teks berbahasa Inggrisnya ditranslasi menjadi Bahasa Indonesia serta korpus paralel Indonesia-Inggris yang teks berbahasa Inggrisnya dibangkitkan menjadi graf AMR @putra2022.
Teknik augmentasi data oleh #icite("lee2022") terbukti dapat meningkatkan kinerja #t.amrparsing lintas bahasa untuk Bahasa Cina, Jerman, Italia, dan Spanyol.

Berdasarkan premis-premis tersebut, disusun hipotesis sebagai berikut:

*Hipotesis:*
Model #t.amrparsing #t.linbhs untuk Bahasa Indonesia dapat meningkatkan kinerja dengan menggunakan teknik #t.gpretraining AMRBART menggunakan model bahasa #t.multil dengan dataset yang dibangun dari dataset pasangan teks berbahasa Inggris dan graf AMR serta korpus paralel Indonesia-Inggris dengan teknik augmentasi data.
