#import "/globals.typ": *

== Latar Belakang

//~ NLP
Teks yang dapat dipahami oleh manusia tidak dapat dipahami secara langsung oleh model _natural language processing_ sehingga diperlukan sebuah bentuk representasi lain.
Ada beberapa teknik dalam membuat representasi dari sebuah teks, seperti _bag of words_, _n-gram_, #t.wordem, _semantic role labeling_, dan @AMR.
Dari representasi-representasi tersebut, dapat dilakukan berbagai macam _task_ seperti peringkasan teks, klasifikasi sentimen, mesin translasi, _question-answering_, dan #t.deop.

//~ AMR
@AMR merupakan salah satu representasi yang memperhatikan semantik pada tingkat kalimat dalam bentuk struktur data graf berarah yang mempunyai akar @banarescu2013.
@AMR awalnya didesain untuk merepresentasikan kalimat berbahasa Inggris sehingga bentuk graf @AMR juga dituliskan dengan Bahasa Inggris.
Sebuah teks yang mengandung banyak kalimat dapat direpresentasikan menjadi beberapa graf @AMR, dengan setiap graf merepresentasikan setiap kalimat.
Dalam membuat sebuah @AMR dari sebuah kalimat, perlu dilakukan sebuah proses yang dinamakan #t.amrparsing.

//~ AMR Parsing Techniques
#t.amrparsing dapat dikategorikan menjadi dua pendekatan, yaitu dua tahap _parsing_ dan satu tahap _parsing_ @cai2020.
Pada pendekatan dua tahap _parsing_ digunakan desain _pipeline_ untuk identifikasi konsep dan prediksi relasi.
Pada pendekatan satu tahap _parsing_ dikategorikan menjadi tiga jenis, yaitu _parsing_ berbasis transisi, _parsing_ berbasis @seq2seq, dan _parsing_ berbasis graf.
Pendekatan satu tahap jenis _parsing_ berbasis transisi dilakukan dengan memproses kalimat dari kiri ke kanan dan membangun grafik secara bertahap dengan secara bergantian memasukkan simpul atau sisi baru.
Pendekatan satu tahap jenis _parsing_ berbasis @seq2seq dengan melihat _parsing_ sebagai transduksi urutan linear ke urutan linear juga dengan memanfaatkan linearisasi grafik AMR.
Pendekatan satu tahap jenis _parsing_ berbasis graf di mana setiap langkah waktu, simpul baru beserta koneksinya ke simpul yang ada diputuskan bersama secara berurutan maupun paralel.

//~ AMRBART
Model AMR parsing terbaik saat ini berbasis model bahasa BART yang disebut AMRBART dengan menggunakan teknik #t.gpretraining @bai2022.
AMRBART merupakan model #t.sota dengan kinerja @SMATCH 85.4 pada dataset AMR 2.0 dan 84.2 pada dataset @AMR 3.0 @bai2022.
Sebagai perbandingan, kinerja @stog @zhang2019 memiliki kinerja 76.3 pada dataset AMR 2.0.

//~ Graph-pre-training vs post-training
#t.Gpretraining merupakan proses _post-training_ yang dilakukan pada sebuah _pre-trained model_.
#t.Gpretraining dilakukan oleh #icite("bai2022") dengan melakukan masking pada input dengan tujuan untuk membantu model memahami konteks keterhubungan kalimat dan @AMR.

//~ Metrics and Dataset
Dalam mengukur kelayakan hasil graf @AMR yang dihasilkan dari suatu teknik, digunakan metrik @SMATCH @cai2013.
@SMATCH mengukur derajat _overlap_ antara dua struktur fitur semantik graf @AMR.
Teknik-teknik #t.amrparsing tersebut diukur kelayakannya menggunakan dataset pasangan teks berbahasa Inggris dengan graf AMR-nya.

//~ XL-AMR
#t.amrparsing awalnya dirancang untuk mengubah dari kalimat berbahasa Inggris menjadi sebuah graf @AMR berbahasa Inggris.
@AMR dalam bahasa selain Bahasa Inggris memiliki banyak limitasi karena @AMR berbahasa Inggris sudah dikembangkan lebih dahulu dan memiliki anotasi konsep dan relasi lengkap yang tidak dimiliki @AMR bahasa lain.
Ada beberapa teknik yang dapat membaca kalimat bahasa lain menjadi graf @AMR berbahasa Inggris untuk merepresentasikan kalimat dari bahasa selain Bahasa Inggris.
#icite("damonte2018") mengusulkan teknik #t.amrparsing lintas bahasa, yaitu teknik mengubah kalimat dari bahasa selain Bahasa Inggris menjadi @AMR berbahasa Inggris.
Dalam teknik tersebut, dibutuhkan dataset pasangan teks bahasa target dengan graf @AMR berbahasa Inggris.
Model @XL-AMR memiliki kinerja @SMATCH 53.0 untuk Bahasa Cina, 53.0 untuk Bahasa Jerman, 58.1 untuk Bahasa Italia, dan 58.0 untuk Bahasa Spanyol.

//~ ID-ID Conventional AMR Parsing
Pada @AMR berbahasa Indonesia, telah dikembangkan untuk _parsing_ berbasis #t.mono (Severina & Khodra, 2019; Ilmy & Khodra, 2020) dan #t.linbhs @putra2022.
@AMR berbahasa Indonesia #t.mono masih terbatas karena kurangnya panduan anotasi dan PropBank untuk adaptasi @AMR dalam Bahasa Indonesia.
Dataset yang digunakan sebagai data pelatihan model @AMR yang ada sebanyak 1,130 pasangan kalimat dan graf AMR berbahasa Indonesia.
Anotasi pada dataset tersebut hanya terbatas pada 6 relasi saja, yaitu `:ARG0`, `:ARG1`, `:name`, `:time`, `:location`, dan `:mod` @ilmy2020.
Konsep yang membutuhkan argumen relasi lebih banyak yang tidak tersedia akan diabaikan sehingga AMR Bahasa Indonesia tidak dapat merepresentasikan kalimat yang lebih panjang dan kompleks.

//~ XL-AMR Indonesia
#icite("banarescu2013") secara eksplisit menyebutkan bahwa @AMR tidak didesain sebagai sebuah _interlingua_.
Namun penelitian akhir-akhir ini menunjukkan bahwa @AMR Bahasa Inggris dapat digunakan untuk merepresentasikan kalimat berbahasa selain Inggris.
Minimnya spesifikasi @AMR Bahasa Indonesia juga menjadi motivasi utama dalam menggunakan @AMR lintas bahasa.
Struktur @AMR Bahasa Inggris juga memiliki struktur abstrak yang mirip dengan bahasa pada umumnya @xue2014 sehingga penggunaan @AMR lintas bahasa dapat dijustifikasi.

#icite("putra2022") melatih @XL-AMR @blloshmi2020 berbasis @stog @zhang2019 untuk membangun #t.amrparser dari kalimat berbahasa Indonesia menjadi graf @AMR berbahasa Inggris.
Model @stog menggunakan pendekatan dua tahap _parsing_, yaitu tahap identifikasi konsep dan tahap prediksi relasi.
Model #t.amrparsing lintas bahasa memanfaatkan #t.mwordem dalam memahami konteks setiap bahasa yang dibutuhkan.
Model @stog menggunakan mBERT @conneau2019 sebagai #t.mwordem.
Terdapat beberapa model lain yang mendukung #t.mwordem, seperti mBART @liu2020 yang merupakan versi #t.multil dari BART @lewis2020, dan mT5 @xue2021 yang merupakan versi #t.multil dari T5 @raffel2020.
Teknik #t.amrparsing lintas bahasa dapat memanfaatkan _silver dataset_ yang dapat dibuat dari dataset AMR dan korpus paralel.

#icite("putra2022") menggunakan Dataset AMR 2.0 dan korpus paralel PANL-BPPT sebagai data latihnya.
Kalimat Bahasa Inggris dari Dataset AMR 2.0 ditranslasi menjadi Bahasa Indonesia untuk menghasilkan dataset berkualitas _silver_.
_Silver dataset_ dari AMR 2.0 dibangun dari pasangan kalimat Bahasa Inggris dan graf AMR Bahasa Inggris menjadi pasangan kalimat Bahasa Inggris, kalimat Bahasa Indonesia, dan graf AMR Bahasa Inggris.
Kalimat Bahasa Inggris dari korpus paralel PANL-BPPT dilakukan _parsing_ ke graf @AMR juga untuk menghasilkan dataset berkualitas _silver_.
_Silver dataset_ dari korpus paralel dibangun dari pasangan kalimat Bahasa Inggris dan kalimat Bahasa Indonesia menjadi pasangan kalimat Bahasa Inggris, kalimat Bahasa Indonesia, dan graf AMR Bahasa Inggris.
#icite("putra2022") mengevaluasi kualitas _silver dataset_ dari AMR 2.0 dengan menilai kedekatan kalimat hasil translasi menggunakan #t.cossim.
_Baseline_ dari penelitian tersebut menggunakan teknik #t.tnp @uhrig2021 di mana kalimat berbahasa Indonesia ditranslasikan ke Bahasa Inggris lalu dilakukan #t.amrparsing untuk mendapatkan graf @AMR Bahasa Inggris.
Teknik #t.tnp digunakan karena merupakan _baseline_ yang kuat karena hasil kinerjanya masih jauh melampaui hasil model lintas bahasa lainnya.
Model terbaik dari penelitian #icite("putra2022") menghasilkan kinerja @SMATCH 51.0.
Kinerja tersebut masih kalah dengan _baseline_-nya yang menggunakan teknik #t.tnp dengan kinerja @SMATCH 62.5.
Hal ini diduga karena jumlah dan kualitas _silver dataset_ yang dihasilkan masih belum maksimal, dan model yang dihasilkan belum menggunakan teknik pelatihan model yang lebih baik.

_Silver dataset_ yang dibangun oleh #icite("putra2022") merupakan pasangan data <`ID`, `EN`, `AMR`> yang terdiri dari: kalimat berbahasa Indonesia (`ID`), kalimat berbahasa Inggris (`EN`), dan graf AMR berbahasa Inggris (`AMR`).
Dataset tersebut dibangun dari korpus paralel PANL-BPPT <`ID`, `EN`> dengan melakukan #t.amrparsing bagian kalimat Bahasa Inggris (`EN`) ke @AMR Bahasa Inggris (`AMR`), dan dari AMR 2.0 <`EN`, `AMR`> dengan mentranslasikan kalimat Bahasa Inggris (`EN`) ke Bahasa Indonesia (`ID`).

#icite("lee2022") memperkenalkan teknik augmentasi data dalam menghasilkan data latih untuk model #t.amrparsing lintas bahasa.
Teknik ini menghasilkan lebih banyak pasangan graf @AMR dan kalimat dengan bahasa target, sehingga model yang dilatih dapat menghasilkan kinerja yang lebih baik.
Teknik tersebut meningkatkan kinerja @SMATCH pada model XL-AMR @blloshmi2020 menjadi 63.0 untuk Bahasa Cina, 73.7 untuk Bahasa Jerman, 76.1 untuk Bahasa Italia, dan 77.1 untuk Bahasa Spanyol.
