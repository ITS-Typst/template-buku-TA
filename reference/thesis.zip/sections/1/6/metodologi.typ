#import "/globals.typ": *

== Metodologi

Berikut adalah tahapan atau metodologi yang dilakukan dalam proses penulisan tesis ini.

+ Analisis Masalah \
  Tahap awal dilakukan analisis permasalahan dalam melakukan #t.amrparsing dalam Bahasa Indonesia.
  Hal ini dilakukan dengan mendalami materi mengenai teknik-teknik #t.amrparsing yang ada sebelumnya dan membandingkan hasil kinerjanya.

+ Perancangan Solusi dan Implementasi \
  Pada tahap ini dilakukan perancangan dan implementasi berdasarkan hasil analisis teknik-teknik #t.amrparsing sebelumnya.
  Dirancang sebuah solusi dengan menggunakan beberapa gabungan teknik dan model tersebut.
  Lalu dilakukan implementasi dari rancangan tersebut dengan melakukan _training_ model terhadap dataset yang tersedia.

+ Eksperimen dan Pengujian \
  Eksperimen dilakukan untuk menganalisis pengaruh implementasi terhadap kinerja model yang dihasilkan.
  Hasil implementasi sebelumnya diuji dan dievaluasi secara kuantitatif dengan menggunakan metrik @SMATCH untuk dibandingkan hasilnya dengan teknik sebelumnya.
  Hasil #t.amrparsing juga diuji dengan melakukan task #t.deop berdasarkan metrik @SMATCH.
  Pengujian tersebut digunakan untuk kesimpulan kelayakan model #t.amrparsing #t.linbhs untuk kalimat berbahasa Indonesia.
