#import "/globals.typ": *

== Masalah Penelitian

#t.amrparser #t.linbhs untuk Bahasa Indonesia telah dikembangkan oleh #icite("putra2022") yang menggunakan teknik @stog @zhang2019.
Banyak model lain yang memiliki kinerja #t.amrparsing #t.mono yang lebih baik dari @stog, seperti AMRBART @bai2022.
_Gold dataset_ yang digunakan oleh #icite("putra2022") juga belum menggunakan dataset terbaru, yakni AMR 3.0, yang memiliki kalimat lebih banyak dari AMR 2.0.
Korpus paralel pasangan Bahasa Inggris dan Bahasa Indonesia, PANL-BPPT @bppt2009 dan IWSLT17 @cettolo2017, dapat digunakan untuk #t.amrparsing untuk kalimat berbahasa Indonesia.
Dataset yang digunakan #icite("putra2022") belum mencakup korpus paralel IWSLT17.

//~ Thesis Problem
Rumusan masalah dari tesis ini adalah bagaimana meningkatkan kinerja #t.amrparser untuk kalimat berbahasa Indonesia menjadi graf @AMR berbahasa Inggris dengan menggunakan dataset @AMR Bahasa Inggris, korpus paralel Bahasa Inggris-Indonesia, dan pendekatan _parsing_ yang lebih baik.
