#import "/globals.typ": *

== Batasan Masalah

Batasan masalah dari tesis ini adalah pemodelan hanya dengan skema pelatihan bilingual sesuai hasil penelitian #icite("putra2022").
