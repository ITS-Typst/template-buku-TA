#import "/globals.typ": *

== Detil Hasil Eksperimen

=== Hasil eksperimen dari Model #models.amrbart-id-large <amrbart-id-large-evaluation-experiment-result>

#figure(create-prf-table(vals.amrbart-id-large))

=== Hasil eksperimen dari Model #models.amrbart-id-trimmed <amrbart-id-experiment-result>

#figure(create-prf-table(vals.amrbart-id-trimmed))

#pagebreak() //? manual alignment

=== Hasil eksperimen dari Model #models.amrbart-id-concat dengan Dataset #ds.amr3-id-augfil <amrbart-id-concat-experiment-result>

#figure(create-prf-table(vals.amrbart-id-concat))

=== Hasil eksperimen dari Model #models.amrbart-id-concat dengan Kalimat Bahasa Inggris Asli <amrbart-id-concat-original-experiment-result>

#figure(create-prf-table(vals.amrbart-id-concat-original))

#pagebreak() //? manual alignment

=== Hasil eksperimen dari Model #models.amrbart-id-concat dengan Dataset #ds.amr2-id <amrbart-id-amr2-experiment-result>

#figure(create-prf-table(vals.amrbart-id-concat-amr2))

=== Hasil eksperimen dari Model #models.amrbart-id-concat dengan Dataset #ds.amr3-id <amrbart-id-amr3-experiment-result>

#figure(create-prf-table(vals.amrbart-id-concat-amr3))

#pagebreak() //? manual alignment

=== Hasil eksperimen dari Model #models.amrbart-id-concat dengan Dataset #ds.amr3-id-aug <amrbart-id-amr3-aug-experiment-result>

#figure(create-prf-table(vals.amrbart-id-concat-amr3-aug))

=== Hasil evaluasi Model #models.ours <amrbart-id-amr3-aug-test-evaluation>

#figure(create-prf-table(tests.ours))
