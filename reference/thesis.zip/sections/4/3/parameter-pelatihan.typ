#import "/globals.typ": *

== Konfigurasi Pelatihan Model

Terdapat dua model yang digunakan, yaitu Model #models.mbart-large dan #models.mbart-trimmed.
Model #models.mbart-trimmed merupakan Model #models.mbart-large yang dihapus bagian kosa kata yang tidak digunakan pada parameter modelnya.
Parameter pelatihan model saat #t.gpretraining dan #t.finetuning dapat dilihat pada @tab--parameter-training.

#fig-tab(
  tablex(
    columns: 2,
    align: (x, y) =>
      if y == 0 or x > 0 {center}
      else {left},
    fill: (x, y) =>
      if y == 0 {gray}
      else if y in (1, 5, 11) {gray.lighten(50%)}
      else {white},
    [*Nama Parameter*],[*Nilai*],
    colspanx(2)[*Konfigurasi Umum*],(),
    [Ukuran Kosa Kata],[38,025 (Trimmed), \ 252,971 (Large-50)],
    [Panjang Maksimal _Sequence_],[512],
    [Total Parameter],[390M (Trimmed), \ 610M (Large-50)],
    colspanx(2)[*#t.Gpretraining*],(),
    [Ukuran _Batch_],[4],
    [_Optimizer_],[Adam],
    [_Learning Rate_],[5e-07],
    [Presisi],[fp32],
    [Jumlah Epoch],[1],
    // [Waktu Training],[~25j (Trimmed), 19j 52m (Large-50)],
    colspanx(2)[*#t.Finetuning*],(),
    [Ukuran _Batch_],[5],
    [_Optimizer_],[Adam],
    [_Learning Rate_],[1e-6],
    [Presisi],[fp32],
    [Jumlah Epoch],[16],
    // [Waktu Training],[~1j 19m (Trimmed), ~50j (Large-50)],
  ),
  caption: [Parameter pelatihan model saat #t.gpretraining dan #t.finetuning.],
) <tab--parameter-training>

_Learning rate_ yang digunakan mengikuti penelitian #icite("bai2022"), namun pada _fine-tuning_, kinerja model masih buruk.
_Learning rate_ pada _fine-tuning_ diubah dengan mencoba nilai yang lebih rendah maupun lebih tinggi, dan didapatkan nilai _learning rate_ yang lebih rendah memiliki kinerja yang lebih baik.
