#import "/globals.typ": *

== Pembangunan Dataset

Pelatihan model #t.amrparsing membutuhkan data latih, validasi, dan uji.
Setiap data yang diperlukan adalah pasangan graf @AMR, kalimat berbahasa Inggris, dan kalimat berbahasa Indonesia.
Sumber dataset yang digunakan adalah data latih AMR 3.0, data validasi AMR 3.0, data uji AMR 2.0, Korpus paralel PANL-BPPT, dan Korpus paralel IWSLT17.
Data uji AMR 2.0 juga mengandung kalimat berbahasa Indonesia hasil translasi ahli yang didapat dari penelitian #icite("putra2022").
Jenis data dan tahapan pembangunan masing-masing dataset dapat dilihat pada @tab--original-dataset.

#fig-tab(
  tablex(
    columns: 7,
    align: (x, y) => if y == 0 or x >= 4 {center} else if x == 3 {right} else {left},
    [*Tahap*],[*Dataset*],[*Sumber*],[*Jumlah*],[*AMR*],[*EN*],[*ID*],
    rowspanx(2)[#t.Gpretraining],rowspanx(2)[Par],[PANL-BPPT],print-number(ds-counts.panl-bppt),[],[$✓$],[$✓$],
    (),(),[IWSLT17],print-number(ds-counts.iwslt17),[],[$✓$],[$✓$],
    rowspanx(3)[#t.Finetuning],[Train],[Data latih \ AMR 3.0],print-number(ds-counts.amr3-train),[$✓$],[$✓$],[],
    (),[Dev],[Data validasi \ AMR 3.0],print-number(ds-counts.amr3-dev),[$✓$],[$✓$],[],
    (),[Test],[Data uji \ AMR 2.0],print-number(ds-counts.amr2-test),[$✓$],[$✓$],[$✓$],
  ),
  caption: [Detail ketersediaan data dari masing-masing dataset.],
) <tab--original-dataset>

Tahapan yang dilakukan dalam membangun pasangan graf @AMR, kalimat berbahasa Inggris, dan kalimat berbahasa Indonesia dari kumpulan dataset tersebut adalah:

+ Melakukan #t.amrparsing kalimat berbahasa Inggris dari Korpus paralel PANL-BPPT dan Korpus paralel IWSLT17 menggunakan algoritma MBSE @lee2022.
  Proses ini menghasilkan @AMR dengan format PENMAN (`AMR`).
+ Melinearisasi semua graf @AMR dengan format DFS (`AMR-DFS`).
+ Melakukan #t.AMRtoTEXT graf @AMR dari data latih AMR 3.0 untuk mendapatkan alternatif kalimat berbahasa Inggris (`EN-ALT`).
+ Melakukan translasi semua kalimat berbahasa Inggris original dan alternatif dari data latih AMR 3.0 dan data validasi AMR 3.0 menjadi kalimat berbahasa Indonesia (`ID` dan `ID-ALT`).
+ Melakukan translasi kembali semua kalimat berbahasa Indonesia dari tahap 4 menjadi kalimat berbahasa Inggris (`EN-BACK` dan `EN-ALT-BACK`).

Tahapan pembangunan kalimat alternatif menggunakan #t.AMRtoTEXT menambah jumlah data latih AMR 3.0 menjadi dua kali lipat, yaitu #print-number(ds-counts.amr3-train-aug).
Hasil dataset yang dibangun kemudian dievaluasi dan difiltrasi dari yang buruk untuk mendapatkan kualitas dataset yang baik sebagai data latih.
Dataset yang dilakukan evaluasi dan filtrasi adalah data latih AMR 3.0.
Evaluasi kualitas dataset dilakukan dengan menghitung tiga jenis skor evaluasi sebagai berikut:

+ #t.Cossim dari _sentence embedding_ kalimat berbahasa Indonesia dan kalimat berbahasa Inggris menggunakan @LABSE: `EN` dengan `ID` dan `EN-ALT` dengan `ID-ALT`.
+ Peringkat _nearest neighbor_ kedekatan _sentence embedding_ dari kalimat berbahasa Indonesia dengan pasangan kalimat berbahasa Inggris dibandingkan dengan kalimat berbahasa Inggris lainnya: `ID` dengan `EN` dan `ID-ALT` dengan `EN-ALT`.
+ Skor @BLEU dari pasangan kalimat berbahasa Inggris dan kalimat berbahasa Inggris hasil translasi kembali dari Bahasa Indonesia: `EN` dengan `EN-BACK` dan `EN-ALT` dengan `EN-ALT-BACK`.
+ Skor @BLEU dari pasangan kalimat berbahasa Inggris dan kalimat alternatif berbahasa Inggris dari hasil #t.AMRtoTEXT: `EN` dengan `EN-ALT`.

Berdasarkan hasil evaluasi tersebut dilakukan filtrasi data untuk menghasilkan kualitas data latih yang lebih baik.
Filtrasi-filtrasi data yang dilakukan adalah sebagai berikut:

+ Skor @BLEU antara `EN` dan `EN-ALT` di antara 0.1 dan 0.9 dengan tujuan menghindari kalimat alternatif yang terlalu mirip dan yang terlalu berbeda @lee2022.
+ Peringkat _nearest neighbor_ kedekatan _sentence embedding_ dari kalimat berbahasa Indonesia dengan pasangan kalimat berbahasa Inggris dibandingkan dengan kalimat berbahasa Inggris lainnya yang memiliki kedekatan peringkat satu #[(]@1-NN) @blloshmi2020.

Hasil evaluasi sebelum dan sesudah dilakukan filtrasi dapat dilihat pada @tab--before-and-after-filtration.
Nilai cosine similarity berhasil meningkat sebanyak #print-number(ds-qualities.amr3-train-augfil.cos-sim - ds-qualities.amr3-train-aug.cos-sim, d: 2) poin.
Nilai BLEU-back juga berhasil meningkat sebanyak #print-number(ds-qualities.amr3-train-augfil.bleu-back - ds-qualities.amr3-train-aug.bleu-back, d: 2) poin.
Peningkatan kualitas tersebut terjadi penghapusan data berkualitas buruk sebanyak #print-number(ds-counts.amr3-train-aug - ds-counts.amr3-train-augfil) data.

#fig-tab(
  tablex(
    columns: 4,
    align: (x, y) =>
      if y == 0 {center}
      else if x > 0 {right}
      else {left},
    [],[*Jumlah*],[*Cosine Similarity*],[*BLEU-back*],
    [Sebelum Filtrasi],print-number(ds-counts.amr3-train-aug),print-number(ds-qualities.amr3-train-aug.cos-sim, d: 2),print-number(ds-qualities.amr3-train-aug.bleu-back, d: 2),
    [Setelah Filtrasi],print-number(ds-counts.amr3-train-augfil),print-number(ds-qualities.amr3-train-augfil.cos-sim, d: 2),print-number(ds-qualities.amr3-train-augfil.bleu-back, d: 2),
  ),
  caption: [Hasil pengaruh filtrasi pada data latih AMR 3.0 setelah dilakukan augmentasi.],
) <tab--before-and-after-filtration>

Pada penelitian ini dibangun 4 macam data latih untuk #t.finetuning yang dilakukan pada eksperimen, yaitu:

+ #ds.amr2-id: Data latih AMR 2.0 dengan translasi ke Bahasa Indonesia.
+ #ds.amr3-id: Data latih AMR 3.0 dengan translasi ke Bahasa Indonesia.
+ #ds.amr3-id-aug: Data latih AMR 3.0 dengan translasi ke Bahasa Indonesia dan augmentasi.
+ #ds.amr3-id-augfil: Data latih AMR 3.0 dengan translasi ke Bahasa Indonesia, augmentasi, dan filtrasi.

Sedangkan untuk #t.gpretraining, digunakan dataset dari korpus paralel yang telah dilakukan _parsing_ dari kalimat Bahasa Inggris ke @AMR.
