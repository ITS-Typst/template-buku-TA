#import "/globals.typ": *

== Pemangkasan Kosa Kata Model mBART

Model #models.mbart-large yang tersedia dari HuggingFace digunakan pada penelitian ini.
Pemangkasan kosa kata dilakukan pada model tersebut untuk menghasilkan model yang berukuran lebih kecil.
_Library_ bernama #t.hf-trim yang dikembangkan oleh #icite("srivastava2022") digunakan untuk melakukan pemangkasan tersebut.
Kode Python yang digunakan dapat dilihat pada @code--hf-trim-implementation.

#fig-code(
  codes.mbart-trimming,
  caption: [Kode Python untuk membangun Model #models.mbart-trimmed menggunakan library #t.hf-trim.],
) <code--hf-trim-implementation>

Arsitektur Model #models.mbart-large dapat dilihat dalam bentuk PyTorch summary pada @code--mbart-large-pytorch-model.
Arsitektur Model #models.mbart-trimmed dapat dilihat dalam bentuk PyTorch summary pada @code--mbart-trimmed-pytorch-model.
Perbedaan utama hasil pemangkasan kosa kata adalah bentuk fitur embedding pada input dan bentuk output yang dikeluarkan.
Jumlah jenis token berubah dari #print-number(vocab-counts.mbart-large) jenis token pada Model #models.mbart-large menjadi #print-number(vocab-counts.mbart-trimmed) jenis token pada Model #models.mbart-trimmed.
Perubahan tersebut dapat dilihat pada layer embedding (`shared`), `embed_tokens` pada _encoder_ dan _decoder_, dan `lm-head`.

#fig-code(
  pytorch-models.mbart-large,
  caption: [Arsitektur Model #models.mbart-large (dipersingkat).],
) <code--mbart-large-pytorch-model>

#fig-code(
  pytorch-models.mbart-trimmed,
  caption: [Arsitektur Model #models.mbart-trimmed (dipersingkat).],
) <code--mbart-trimmed-pytorch-model>

#let jap-word = text(font: "Noto Serif CJK JP")[食]

Masing-masing kemudian model dicoba untuk menghasilkan vektor _embedding space_ dari bagian _encoder_-nya untuk kalimat "UN Chief Says There Is No <mask> in Syria".
Kedua model tersebut menghasilkan vektor _embedding space_ yang sama.
Namun apabila kalimat input tersebut ditambahkan sebuah kata dari Bahasa Jepang, yaitu menjadi "UN Chief Says There Is No <mask> in Syria #jap-word", hasil vektor _embedding space_-nya berbeda.
Pada model dengan kosa kata yang terpotong, kata "#jap-word" menjadi token _unknown_ (_Out-of-vocabulary_) karena tidak termasuk pada kosa kata yang disimpan.
Berdasarkan hal ini dapat dilihat bahwa penghapusan sebagian kosa kata tidak akan berpengaruh pada hasil vektor _embedding space_ apabila input yang masuk dapat dikenali pada kosa kata yang tersedia.
