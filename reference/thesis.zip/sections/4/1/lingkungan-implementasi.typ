#import "/globals.typ": *

== Lingkungan Implementasi

Proses pelatihan menggunakan Sistem Operasi Ubuntu 20 yang berbasiskan Linux untuk kemudahan kompatibilitas dengan GPU NVIDIA yang tersedia.
Spesifikasi lingkungan implementasi ini menentukan lama proses pelatihan yang dilakukan.
Lingkungan implementasi tersebut memiliki spesifikasi yang dapat dilihat pada @tab--lingkungan-implementasi.
Model diimplementasikan menggunakan _Pytorch_ dan _Huggingface Transformers_.
Sumber kode dapat diakses pada #rawlink("https://github.com/nafkhanzam-thesis/AMRBART-id").

#fig-tab(
  tablex(
    columns: 2,
    align: (x, y) => if y == 0 {center} else {left},
    [*Atribut*],[*Spesifikasi*],
    [Sistem Operasi],[Ubuntu 20],
    [Bahasa Pemrograman],[Python 3.8],
    [Processor],[Intel Xeon Gold 6148],
    [Memory],[16 GB],
    [GPU],[RTX A6000 48 GB],
  ),
  caption: [Lingkungan implementasi untuk pelatihan.],
) <tab--lingkungan-implementasi>


