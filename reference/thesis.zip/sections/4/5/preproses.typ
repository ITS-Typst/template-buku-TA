#import "/globals.typ": *

== _Preprocess_ Data Pelatihan

Berdasarkan penelitian #icite("bai2022"), preproses dilakukan dengan mengubah penulisan @AMR menjadi bentuk linearisasi @DFS.
Teknik tokenisasi dilakukan berdasarkan model yang digunakan.
Hasil preproses tersebut digabung menjadi input yang linear pada model.
_Prefix_ token yang digunakan disesuaikan dengan kosa kata yang dimiliki oleh model mBART.
_Prefix_ token pada model mBART sesuai dengan format #t.gpretraining yang sudah dilakukan.
Pasangan token yang digunakan pada model mBART dapat dilihat pada @tab--pasangan-token-mbart.
Data input yang memiliki panjang _sequence_ melebihi maksimal panjang _sequence_ pada konfigurasi model akan dipotong bagian akhir dari @AMR.
Maksimal _sequence_ pada konfigurasi model mBART yang digunakan adalah 512.

#fig-tab(
  tablex(
    columns: 2,
    align: center,
    [*Token*],[*Token pada mBART*],
    [`<id>`],[`id_ID`],
    [`<en>`],[`en_XX`],
    [`<g>`],[`<AMR>`],
    [`</g>`],[`</AMR>`],
  ),
  caption: [Pasangan token yang digunakan pada Model mBART.],
) <tab--pasangan-token-mbart>

Banyak data dan token yang harus dipotong berdasarkan pada dataset latih dapat dilihat pada @tab--trim-counts.
Banyak data yang terpotong paling banyak terjadi pada tahap #t.gpretraining dengan #t.concat, yaitu 0.36%.
Rata-rata jumlah token yang terpotong terbanyak adalah 0.17 token per data. Angka tersebut sangatlah sedikit sehingga penggunaan #t.concat dengan batas maksimal _sequence_ sebanyak 512 tidak terlalu menghilangkan banyak informasi input.
Tidak ada hasil _output_ graf @AMR yang terpotong.
Contoh preproses dan linearisasi pada sebuah data dapat dilihat pada @tab--contoh-preprocess.

#let gen-table(title: [], data: (), totals: ()) = {
  let res = (colspanx(3)[#title],(),())
  let parts = (t.Gpretraining, t.Finetuning)
  for (i, part) in parts.enumerate() {
    res.push(part)
    let data-count = data.at(i*2)
    let trim-count = data.at(i*2 + 1)
    let data-total = totals.at(i)
    let count-percent = data-count*100/data-total
    res.push([#print-number(data-count) dari #print-number(data-total) (#print-number(count-percent, d: 2)%)])
    let avg = if data-count == 0 { 0 } else { trim-count/data-total }
    res.push([#print-number(avg, d: 2) token / data])
  }
  return res
}

#fig-tab(
  tablex(
    columns: 3,
    align: (x, y) =>
      if y == 0 {center}
      else if x > 0 {right}
      else {left},
    fill: (x, y) =>
      if y == 0 {gray}
      else if y in (1, 4) {gray.lighten(50%)}
      else {white},
    [*Tahap _training_*],[*Jumlah Data Terpotong*],[*Rata-rata Token Terpotong*],
    ..gen-table(
      title: [Tanpa #t.concat],
      data: (
        206, 7513,
        0, 0,
      ),
      totals: (
        ds-counts.parallel-corpora*2,
        ds-counts.amr3-train-augfil*2,
      ),
    ),
    ..gen-table(
      title: [Dengan #t.concat],
      data: (
        478, 22595,
        3, 1,
      ),
      totals: (
        ds-counts.parallel-corpora,
        ds-counts.amr3-train-augfil,
      ),
    ),
  ),
  caption: [Jumlah data dan token yang terpotong pada dataset latih.],
) <tab--trim-counts>

#{
  set page(flipped: true)
  set text(hyphenate: false)
  [
    #fig-tab(
      tablex(
        columns: (auto, 1fr),
        align: (x, y) => if y == 0 {center} else {left},
        [*Jenis Data*],[*Contoh Data*],
        [Kalimat Bahasa Inggris],text(size: 0.8em)[TMT : I don't understand your point.],
        [Kalimat Bahasa Indonesia],text(size: 0.8em)[TMT : saya tidak mengerti maksud anda.],
        [AMR],text(size: 0.8em)[(s / say-01 :ARG0 (i / i) :ARG1 (u / understand-01 :polarity - :ARG0 i :ARG1 (p2 / point :poss p)) :ARG2 (p / person :wiki - :name (t / name :op1 "TMT")))],
        [AMR DFS],text(size: 0.8em)[( \<p:0> say-01 :ARG0 ( \<p:1> i ) :ARG1 ( \<p:2> understand-01 :polarity - :ARG0 \<p:1> :ARG1 ( \<p:3> point :poss \<p:4> ) ) :ARG2 ( \<p:4> person :wiki - :name ( \<p:5> name :op1 "TMT" ) ) )],
        [Input #t.Gpretraining (ID)],text(size: 0.8em)[id_ID TMT : saya tidak mengerti maksud anda. \<AMR> ( \<p:0> say-01 :ARG0 ( \<p:1> i ) :ARG1 ( \<p:2> understand-01 :polarity - :ARG0 \<p:1> :ARG1 ( \<p:3> point :poss \<p:4> ) ) :ARG2 ( \<p:4> person :wiki - :name ( \<p:5> name :op1 "TMT" ) ) ) \</AMR>],
        [Input #t.Gpretraining (EN)],text(size: 0.8em)[en_XX TMT : I don't understand your point. \<AMR> ( \<p:0> say-01 :ARG0 ( \<p:1> i ) :ARG1 ( \<p:2> understand-01 :polarity - :ARG0 \<p:1> :ARG1 ( \<p:3> point :poss \<p:4> ) ) :ARG2 ( \<p:4> person :wiki - :name ( \<p:5> name :op1 "TMT" ) ) ) \</AMR>],
        [Input #t.Gpretraining \ dengan #t.concat],text(size: 0.8em)[id_ID TMT : saya tidak mengerti maksud anda. en_XX TMT : I don't understand your point. \<AMR> ( \<p:0> say-01 :ARG0 ( \<p:1> i ) :ARG1 ( \<p:2> understand-01 :polarity - :ARG0 \<p:1> :ARG1 ( \<p:3> point :poss \<p:4> ) ) :ARG2 ( \<p:4> person :wiki - :name ( \<p:5> name :op1 "TMT" ) ) ) \</AMR>],
        [Input #t.Finetuning / Inferensi (ID)],text(size: 0.8em)[id_ID TMT : saya tidak mengerti maksud anda. \<AMR> \<mask> \</AMR>],
        [Input #t.Finetuning / Inferensi (EN)],text(size: 0.8em)[en_XX TMT : I don't understand your point. \<AMR> \<mask> \</AMR>],
        [Input #t.Finetuning / Inferensi \ dengan #t.concat],text(size: 0.8em)[id_ID TMT : saya tidak mengerti maksud anda. en_XX TMT : I don't understand your point. \<AMR> \<mask> \</AMR>],
        [_Output_],text(size: 0.8em)[\<AMR> ( \<p:0> say-01 :ARG0 ( \<p:1> i ) :ARG1 ( \<p:2> understand-01 :polarity - :ARG0 \<p:1> :ARG1 ( \<p:3> point :poss \<p:4> ) ) :ARG2 ( \<p:4> person :wiki - :name ( \<p:5> name :op1 "TMT" ) ) ) \</AMR>],
      ),
      caption: [Contoh preproses data untuk pelatihan dan inferensi.],
    ) <tab--contoh-preprocess>
  ]
}

Graf @AMR DFS yang dihasilkan model kemudian diubah kembali menjadi format PENMAN.
Langkah selanjutnya adalah melakukan proses _wikification_, yaitu dengan menambahkan relasi `:wiki` yang sesuai pada graf @AMR dalam format PENMAN.
_Wikification_ dilakukan dengan menggunakan arsitektur BLINK @wu2019.
Contoh hasil _wikification_ dapat dilihat pada @tab--wikification-example.

#fig-tab(
  tablex(
    columns: 2,
    align: (x, y) => if y == 0 {center} else {left},
    [],[*AMR*],
    [Sebelum _wikification_],
    ```amr
(z0 / thing
      :wiki -
      :name (z1 / name
            :op1 "EMR"))
    ```,
    [Setelah _wikification_],
    ```amr
(z0 / thing
      :wiki "Endoscopic_mucosal_resection"
      :name (z1 / name
            :op1 "EMR"))
    ```,
  ),
  caption: [Contoh hasil _wikification_ pada sebuah @AMR.],
) <tab--wikification-example>
