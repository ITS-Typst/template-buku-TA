#import "/globals.typ": *

== Eksperimen

Tujuan eksperimen adalah untuk: #inline-list(
  [menginvestigasi pengaruh pemangkasan sebagian dari kosa kata model],
  [menginvestigasi pengaruh penggunaan #t.concat pada input],
  [menginvestigasi pengaruh pengaruh augmentasi dan filtrasi pada dataset],
  last: [serta],
).
AMR parsing lintas bahasa dilakukan dengan metrik @SMATCH pada dataset AMR 3.0 bagian data validasi menggunakan #t.opus-mt untuk menghasilkan pasangan kalimat Bahasa Indonesia.

=== Menginvestigasi Pengaruh Pemangkasan Sebagian dari Kosa Kata Model

Eksperimen pertama dilakukan untuk memvalidasi model yang dilakukan pemangkasan sebagian kosa kata model.
Dataset latih yang digunakan adalah Dataset AMR 3.0 dengan translasi, augmentasi, dan filtrasi.
Teknik pelatihan yang digunakan adalah teknik pelatihan bilingual.
Model #models.amrbart-id-large merupakan hasil pelatihan dari Model #models.mbart-large.
Hasil eksperimen dari Model #models.amrbart-id-large dapat dilihat pada @amrbart-id-large-evaluation-experiment-result.
Model #models.amrbart-id-trimmed merupakan hasil pelatihan dari Model #models.mbart-trimmed.
Hasil eksperimen dari Model #models.amrbart-id-trimmed dapat dilihat pada @amrbart-id-experiment-result.
Satu-satunya perbedaan antara kedua model tersebut adalah jumlah parameter yang dimiliki masing-masing model.

Perbandingan eksperimen skor F1 dari kedua model tersebut dapat dilihat pada @tab--amrbart-id-f1-difference.
Perbedaan hasil eksperimen kedua model tersebut tidak jauh berbeda dengan selisih #[@SMATCH]-nya adalah #smatch-diff(vals.amrbart-id-large, vals.amrbart-id-trimmed) dan selisih maksimal skor F1 tersebut adalah #max-diff(vals.amrbart-id-large, vals.amrbart-id-trimmed).
Penurunan kinerja tersebut disebabkan oleh adanya kosa kata pada data validasi yang tidak tersedia pada data latih.
Berdasarkan hasil tersebut, penggunaan model dengan kosa kata Bahasa Inggris dan Indonesia yang lebih lengkap dapat menghindari penurunan kinerja model tersebut.

#fig-tab(
  create-f1-comparison-table-narrow(
    col-label: align(left)[*Basis Model*],
    (
      title: models.mbart-large,
      values: vals.amrbart-id-large,
    ),
    (
      title: models.mbart-trimmed,
      values: vals.amrbart-id-trimmed,
    ),
  ),
  caption: [Hasil eksperimen skor F1 Model #models.mbart-large dan #models.mbart-trimmed.],
) <tab--amrbart-id-f1-difference>

#let params-improvement = round-fixed-str(model-specs.mbart-large.params/model-specs.mbart-trimmed.params, 1)
#let file-size-gb-improvement = round-fixed-str(model-specs.mbart-large.file-size-gb/model-specs.mbart-trimmed.file-size-gb, 1)
#let gpt-time-improvement = round-fixed-str(model-specs.mbart-large.gpt-time/model-specs.mbart-trimmed.gpt-time, 1)
#let ft-time-improvement = round-fixed-str(model-specs.mbart-large.ft-time/model-specs.mbart-trimmed.ft-time, 1)

Perbandingan lama waktu yang dibutuhkan untuk melakukan #t.gpretraining dan #t.finetuning dapat dilihat pada @tab--amrbart-id-time-difference.
Model #models.mbart-trimmed dapat mempercepat #t.gpretraining sebanyak #gpt-time-improvement kali lipat dan #t.finetuning sebanyak #ft-time-improvement kali lipat.
Berdasarkan hasil-hasil tersebut, penggunaan Model #models.mbart-trimmed dijustifikasi untuk teknik pelatihan lainnya.

#fig-tab(
  tablex(
    columns: 4,
    align: (x, y) =>
      if x == 0 {left}
      else {center},
    align(left)[*Basis Model*],[*#models.mbart-large*],[*#models.mbart-trimmed*],[*Peningkatan*],
    [*Total Parameter*],[#print-number(model-specs.mbart-large.params)],[#print-number(model-specs.mbart-trimmed.params)],[#params-improvement x],
    [*Ukuran File*],[#print-number(model-specs.mbart-large.file-size-gb) GB],[#print-number(model-specs.mbart-trimmed.file-size-gb) GB],[#file-size-gb-improvement x],
    [*Waktu #t.Gpretraining*],[#model-specs.mbart-large.gpt-time jam],[#model-specs.mbart-trimmed.gpt-time jam],[#gpt-time-improvement x],
    [*Waktu #t.Finetuning*],[#model-specs.mbart-large.ft-time jam],[#model-specs.mbart-trimmed.ft-time jam],[#ft-time-improvement x],
  ),
  caption: [Perbandingan waktu #t.gpretraining dan #t.finetuning untuk Model #models.amrbart-id-large dan #models.amrbart-id-trimmed.],
) <tab--amrbart-id-time-difference>

=== Menginvestigasi Pengaruh Penggunaan #t.Concat pada Input

Pengujian selanjutnya dilakukan untuk membandingkan teknik pelatihan antara penggunaan #t.concat atau tidak.
Dataset latih yang digunakan adalah Dataset AMR 3.0 dengan translasi, augmentasi, dan filtrasi.
Model #models.amrbart-id-trimmed merupakan hasil pelatihan tanpa menggunakan #t.concat dan Model #models.amrbart-id-concat merupakan hasil pelatihan menggunakan #t.concat.
Hasil eksperimen dari Model #models.amrbart-id-trimmed dapat dilihat pada @amrbart-id-experiment-result.
Hasil eksperimen dari Model #models.amrbart-id-concat dapat dilihat pada @amrbart-id-concat-experiment-result.

Perbandingan eksperimen skor F1 dari Model #models.amrbart-id-trimmed, #models.amrbart-id-concat dengan translasi, dan dengan kalimat original Bahasa Inggris dapat dilihat pada @tab--amrbart-id-concat-f1-difference.
Perbedaan hasil eksperimen kedua model tersebut berbeda dengan selisih #[@SMATCH]-nya adalah #smatch-diff(vals.amrbart-id-trimmed, vals.amrbart-id-concat) dengan Model #models.amrbart-id-concat yang memiliki skor lebih baik.
Berdasarkan hasil tersebut, penggunaan teknik pelatihan #t.concat lebih efektif dengan adanya keterkaitan dua data, yaitu kalimat Bahasa Indonesia dan Bahasa Inggris.

#fig-tab(
  create-f1-multi-comparison-table(
    col-label: align(left)[*Model*],
    (
      title: [Tanpa \ #t.concat \ #text(size: 0.85em)[(#models.amrbart-id-trimmed)]],
      values: vals.amrbart-id-trimmed,
    ),
    (
      title: [#t.Concat \ + translasi \ #text(size: 0.85em)[(#models.amrbart-id-concat)]],
      values: vals.amrbart-id-concat,
    ),
    (
      title: [#t.Concat \ + kalimat asli \ #text(size: 0.85em)[(#models.amrbart-id-concat)]],
      values: vals.amrbart-id-concat-original,
    ),
  ),
  caption: [Hasil eksperimen skor F1 pada pengaruh penggunaan #t.concat.],
) <tab--amrbart-id-concat-f1-difference>

Keterkaitan dua bahasa tersebut juga dibuktikan dengan menggunakan kalimat Bahasa Inggris yang asli.
Hasil skor @SMATCH apabila menggunakan kalimat Bahasa Inggris asli dapat mencapai #print-number(vals.amrbart-id-concat-original.at(2), d: 1).
Hasil eksperimen dari Model #models.amrbart-id-concat dengan menggunakan kalimat Bahasa Inggris asli dapat dilihat pada @amrbart-id-concat-original-experiment-result.
Namun, karena dalam melakukan #t.amrparsing pada model ini perlu dilakukan translasi, maka hasil Model #models.amrbart-id-concat dengan translasi yang digunakan sebagai acuan kinerja model ini.
Berdasarkan hasil ini, kualitas hasil translasi juga menjadi poin penting untuk menghasilkan graf @AMR berkualitas tinggi.

=== Menginvestigasi Pengaruh Augmentasi dan Filtrasi pada Dataset

Pengujian selanjutnya dilakukan untuk membandingkan pengaruh augmentasi dan filtrasi pada dataset latih untuk #t.finetuning yang menghasilkan model terbaik.
Basis model yang digunakan adalah Model #models.mbart-trimmed yang telah dilakukan #t.gpretraining graf dengan #t.concat.
Dataset-dataset latih yang dibandingkan untuk #t.finetuning adalah Dataset #ds.amr2-id, #ds.amr3-id, #ds.amr3-id-aug, dan #ds.amr3-id-augfil.
Hasil eksperimen tersebut dapat dilihat pada @amrbart-id-amr2-experiment-result, @amrbart-id-amr3-experiment-result, @amrbart-id-amr3-aug-experiment-result, dan @amrbart-id-experiment-result secara berturut-turut.

Perbandingan eksperimen skor F1 dari semua model tersebut dapat dilihat pada @tab--amrbart-id-dataset-f1-difference.
Berdasarkan hasil tersebut, penggunaan Dataset #ds.amr3-id-augfil merupakan yang paling efektif dalam menghasilkan model terbaik.
Filtrasi yang dilakukan untuk meningkatkan kualitas dataset berdasarkan metrik @BLEU dan algoritma kNN dapat dimanfaatkan untuk meningkatkan kinerja model.
Jumlah dataset juga berpengaruh besar dalam meningkatkan kinerja model #t.amrparsing dari kalimat Bahasa Indonesia ke @AMR Bahasa Inggris.

#fig-tab(
  create-f1-multi-comparison-table(
    col-label: align(left)[*Dataset*],
    (
      title: [AMR 2.0],
      // title: ds.amr2-id,
      values: vals.amrbart-id-concat-amr2,
    ),
    (
      title: [AMR 3.0],
      // title: ds.amr3-id,
      values: vals.amrbart-id-concat-amr3,
    ),
    (
      title: [AMR 3.0 \ + Aug],
      // title: ds.amr3-id-aug,
      values: vals.amrbart-id-concat-amr3-aug,
    ),
    (
      title: [AMR 3.0 \ + Aug + Fil],
      // title: ds.amr3-id-augfil,
      values: vals.amrbart-id-concat,
    ),
  ),
  caption: [Hasil eksperimen pengaruh dataset dengan augmentasi dan filtrasi.],
) <tab--amrbart-id-dataset-f1-difference>
