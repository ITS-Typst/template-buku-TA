#import "/globals.typ": *

== Pengujian

Tujuan pengujian adalah untuk: #inline-list(
  [mengetahui kinerja model untuk #t.amrparsing #t.linbhs untuk Bahasa Indonesia],
  [mengetahui kinerja model untuk melakukan #t.deop dengan menggunakan @AMR],
  last: [dan],
).

=== Pengujian #t.amrparsing #t.Linbhs untuk Bahasa Indonesia

Model #models.ours memiliki skor @SMATCH tertinggi dibandingkan konfigurasi dataset ataupun pelatihan yang lainnya.
Model tersebut akan digunakan untuk evaluasi dan untuk perbandingan dengan model-model sebelumnya.
Juga dilakukan _wikification_ untuk meningkatkan kinerja pada aspek `:wiki` pada @AMR.
Dataset yang digunakan untuk evaluasi adalah data uji dari AMR 2.0 dengan translasi ke Bahasa Indonesia oleh #icite("putra2022").
Hasil evaluasi untuk Model #models.ours dapat dilihat pada @amrbart-id-amr3-aug-test-evaluation.

Pada penelitian sebelumnya, metode #t.tnp dengan model dari #icite("zhang2019") sebagai _baseline_ memiliki kinerja terbaik.
Model yang dibangun oleh #icite("putra2022") tidak memiliki kinerja yang lebih baik dari _baseline_ tersebut.
Dibandingkan dengan model sebelumnya, model terbaik yang dibangun pada penelitian ini, yaitu #models.ours, menghasilkan kinerja yang lebih baik berdasarkan metrik @SMATCH.
Hasil perbandingan model tersebut dengan semua model pada penelitian #icite("putra2022") dapat dilihat pada @tab--all-evaluations.
Model #models.ours memiliki nilai F1 @SMATCH tertinggi dibandingkan model-model sebelumnya, yaitu dengan skor #round-fixed-str(tests-formatted.ours.at(0), 1).
Model #models.ours memiliki skor @SMATCH #round-fixed-str(tests-formatted.ours.at(0) - tests-formatted.tnp-zhang.at(0), 1) lebih banyak dari metode #t.tnp dengan model #icite("zhang2019").

#[
  #set page(flipped: true)
  #fig-tab(
    create-test-comparison-table(
      col-label: [*Model*],
      (
        title: [Translate & Parse Zhang (2019)],
        values: tests-formatted.tnp-zhang,
      ),
      (
        title: models.putra2022,
        values: tests-formatted.mt5-putra,
      ),
      (
        title: models.ours,
        values: tests-formatted.ours,
      ),
    ),
    caption: [Perbandingan hasil evaluasi F1 #t.amrparsing lintas bahasa untuk Bahasa Indonesia pada data uji.],
  ) <tab--all-evaluations>
]

=== Pengujian Deteksi #t.EoP dengan Menggunakan AMR

//? Btw, why didn't Putra (2022) use pure paraphrase detection dataset?
//? For example: https://huggingface.co/datasets/jakartaresearch/id-paraphrase-detection.

Pengujian juga dilakukan pada salah satu task yang dapat memanfaatkan penggunaan @AMR.
Task yang diujikan adalah #t.deop.
Task tersebut telah dilakukan sebelumnya oleh #icite("putra2022") dengan dataset WReTE dari IndoNLU.
Pengujian akan dilakukan dengan dataset yang sama dengan model terbaik pada penelitian ini, yaitu Model #models.ours.

Dataset #t.deop yang digunakan mengandung pasangan dua kalimat Bahasa Indonesia dengan label bahwa kedua kalimat tersebut merupakan parafrase atau tidak.
Teknik evaluasi dilakukan dengan mengenerasi sebuah @AMR untuk masing-masing kalimat.
Kedua @AMR tersebut dihitung kesamaannya dengan metrik @SMATCH.
Secara definisi metrik @SMATCH itu sendiri, semakin tinggi nilainya, semakin mirip semantik dari kedua kalimat tersebut.

Karena model #t.amrparser belum sempurna, susah untuk mendapatkan nilai @SMATCH 100 sebagai pendeteksi kalimat parafrase.
Sehingga diperlukan sebuah _threshold_ sebagai batas penentu antara kedua kalimat tersebut merupakan parafrase atau tidak.
_Threshold_ yang digunakan adalah 48.35.
Pasangan kalimat dengan @SMATCH di atas _threshold_ tersebut diklasifikasikan dengan prediksi #t.eop.
_Threshold_ tersebut ditentukan menggunakan Receiver Operator Characteristic (ROC) _curve_ berdasarkan data validasi.

Pengujian #t.deop pertama dilakukan pada dataset WReTE bagian data validasi.
Hasil evaluasi #t.deop pada dataset WReTE bagian data validasi dapat dilihat pada @tab--paraphrase-detection-evaluation-dev-set.
Evaluasi precision, recall, dan F1 dilakukan rata-rata untuk masing-masing label dengan perhitungan _weighted-average_.
Model yang dibandingkan adalah Model #models.ours dan model dari #icite("putra2022").
Hasil evaluasi menunjukkan bahwa Model #models.ours memiliki kinerja dalam melakukan task #t.deop lebih baik dari model #icite("putra2022") dengan peningkatan skor F1 mencapai #print-number(para-vals.ours.at(3) - para-vals.putra2022.at(3), d: 3).

#fig-tab(
  create-test-comparison-table(
    col-label: [*Model*],
    labels: ([*Acc*],[*P*],[*R*],[*F1*]),
    d: 3,
    (
      title: [AMR Indonesia (Putra, 2022)],
      values: para-vals.amr-id,
    ),
    (
      title: [#models.putra2022],
      values: para-vals.putra2022,
    ),
    (
      title: [#models.ours],
      values: para-vals.ours,
    ),
  ),
  caption: [Perbandingan skor F1 untuk task #t.deop pada data validasi dari Dataset WReTE.],
) <tab--paraphrase-detection-evaluation-dev-set>

Pengujian #t.deop selanjutnya dilakukan pada dataset WReTE bagian data uji.
Hasil evaluasi #t.deop pada dataset WReTE bagian data uji dapat dilihat pada @tab--paraphrase-detection-evaluation-test-set.
Evaluasi precision, recall, dan F1 dilakukan rata-rata untuk masing-masing label dengan perhitungan _macro-average_.
Evaluasi dibandingkan dengan beberapa model dari penelitian #icite("wilie2020") yang menggunakan model berbasis _encoder_ yang dilakukan #t.finetuning untuk task klasifikasi.
Namun skor tersebut masih belum lebih baik dari kinerja dari Model mBERT dengan skor F1 #print-number(para-tests.mbert.at(3), d: 3) dan Model _Fine-tuned_ IndoBERT-lite-large-p2 dengan skor F1 #print-number(para-tests.indobert.at(3), d: 3).

#fig-tab(
  create-test-comparison-table(
    col-label: [*Model*],
    labels: ([*Acc*],[*P*],[*R*],[*F1*]),
    bold-indices: (3,),
    d: 3,
    (
      title: [_Fine-tuned_ mBERT (Wilie, 2020)],
      values: para-tests.mbert,
    ),
    (
      title: [_Fine-tuned_ IndoBERT-lite-large-p2 (Wilie, 2020)],
      values: para-tests.indobert,
    ),
    (
      title: [_Fine-tuned_ fastText-cc-id (Wilie, 2020)],
      values: para-tests.fasttext,
    ),
    (
      title: [#models.ours],
      values: para-tests.ours,
    ),
  ),
  caption: [Perbandingan skor F1 untuk task #t.deop pada data uji dari Dataset WReTE.],
) <tab--paraphrase-detection-evaluation-test-set>

Hasil pengujian dianalisis untuk kesalahan _false positive_ dan _false negative_.
_False positive_ terjadi ketika model memprediksi hasil "Entail or Paraphrase" namun labelnya merupakan "Not Entail nor Paraphrase", sedangkan _false negative_ merupakan sebaliknya.
Ditemukan bahwa sebagian besar kesalahan _false positive_ terjadi karena perubahan minimal dalam kalimat-kalimat tersebut.
Di sisi lain, sebagian besar kesalahan _false negative_ disebabkan oleh kalimat-kalimat yang merupakan entailment teks daripada parafrasa.
Beberapa contoh kesalahan prediksi dapat dilihat pada @tab--example-paraphrase-detection-errors-test-set.
Kalimat-kalimat bahasa Inggris merupakan hasil dari terjemahan mesin menggunakan OPUS-MT dari kalimat-kalimat Indonesia yang sesuai.
Contoh 1 menunjukkan kesalahan _false positive_ yang disebabkan oleh hanya dua perubahan kata.
Karena perubahan-perubahan kecil ini, skor SMATCH tetap lebih tinggi dari ambang batas, mengakibatkan prediksi yang salah.
Contoh 2 dan 3 menggambarkan kesalahan _false negative_.
Contoh 2 mewakili sepasang entailment teks, yang menyebabkan model memprediksinya bukan sebagai parafrasa karena skor SMATCH yang rendah.
Contoh 3 melibatkan kalimat-kalimat panjang dan kompleks, di mana model masih kesulitan dalam memprediksi parafrasa dengan akurat dalam kasus-kasus seperti itu.

#[
  #set par(justify: false)
  #fig-tab(
    tablex(
      columns: (auto, auto, 1fr, 1fr, auto),
      align: (x, y) => if y == 0 {center} else {left},
      [*No.*],[*Lang.*],[*Sentence A*],[*Sentence B*],[*Kesalahan*],
      rowspanx(2)[1],[ID],text(size: 0.75em)[Pada 1964, setelah memegang berbagai jabatan dalam pemerintahan Mesir, ia dipilih oleh Presiden Gamal Abdel Nasser untuk menjabat sebagai #text(red, weight: "bold")[Wakil Presiden].],text(size: 0.75em)[Pada 1964, setelah memegang berbagai jabatan dalam pemerintahan Mesir, ia dipilih oleh Presiden Gamal Abdel Nasser untuk menjabat sebagai #text(red, weight: "bold")[cleaning service].],rowspanx(2)[_false positive_],
      (),[EN],text(size: 0.75em)[In 1964, after holding various positions in the Egyptian government, he was selected by President Gamal Abdel Nasser to serve as #text(red, weight: "bold")[Vice President].],text(size: 0.75em)[In 1964, after holding various positions in the Egyptian government, he was selected by President Gamal Abdel Nasser to serve as #text(red, weight: "bold")[the cleaning service].],(),
      rowspanx(2)[2],[ID],text(size: 0.75em)[Untuk studi falsafi, mutlak diperlukan logika berpikir dan logika bahasa dan filsafat adalah makanan yang bisa membahayakan bagi jiwa.],text(size: 0.75em)[Atau jika kita tidak jeli dalam memahami dan menyikapi filsafat kita bisa tersesat.],rowspanx(2)[_false negative_],
      (),[EN],text(size: 0.75em)[For falsafi studies, absolutely necessary logic of thought and logic of language and philosophy is food that can be harmful to the soul.],text(size: 0.75em)[Or if we are not keen at understanding and dealing with philosophy we could get lost.],(),
      rowspanx(2)[3],[ID],text(size: 0.75em)[Biologi menumpukan kepada ciri-ciri fisikal dan tabiat yang hidup pada masa sekarang, dan masa silam, bagaimana mereka terhasil dan interaksi antara sesama mereka dan alam sekitar.],text(size: 0.75em)[Ilmu biologi berurusan dengan ciri-ciri fisik dan perilaku makhluk hidup pada masa sekarang dan masa lalu, bagaimana mereka tercipta dan interaksi antara sesama mereka dan dengan alam sekitar.],rowspanx(2)[_false negative_],
      (),[EN],text(size: 0.75em)[Biology builds up to the physical traits and traits that live in the present, and the past, how they've produced and interacted with each other and the universe around.],text(size: 0.75em)[Biology deals with the physical traits and behavior of living things in the present and in the past, how they were created and the interaction between their fellow humans and the universe around them.],(),
    ),
    caption: [Contoh kesalahan #t.deop pada data uji.],
  ) <tab--example-paraphrase-detection-errors-test-set>
]
