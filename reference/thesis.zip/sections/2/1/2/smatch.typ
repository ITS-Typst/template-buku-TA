#import "/globals.typ": *

=== _Semantic Match_ (SMATCH)

@SMATCH merupakan metrics untuk mengukur kesamaan antara dua representasi semantik.
Tujuan utama dari semantik parsing adalah untuk menghasilkan hubungan relasi semantik dalam teks.
Hasil dari semantik parsing ini biasanya direpresentasikan oleh struktur semantik suatu kalimat utuh.
Evaluasi dari struktur ini diperlukan untuk tugas parsing semantik dan tugas anotasi semantik yang menghasilkan linguistic resource untuk semantic parsing.
Secara definisi, @SMATCH merupakan nilai f-score maksimal yang didapatkan berdasarkan padanan satu-satu antara dua representasi semantik @cai2013.

Pada kasus ini, @SMATCH digunakan untuk mengukur kesamaan antara dua @AMR.
Sebagai contoh, terdapat dua kalimat representasi @AMR yaitu "_the boy wants to go_" dan "_the boy wants the football_".
Perhitungan @SMATCH dari kedua @AMR ini memerlukan kedua @AMR dalam bentuk format logika proposisi yang terdiri dari relasi(variabel, konsep) dan relasi(variabel1, variabel2).
Setelah itu dapat dihitung presisi, recall, dan f-score dari kesamaan logika proposisi kedua @AMR tersebut.

Sebagai contoh, terdapat dua kalimat "_the boy wants to go_" dan "_the boy wants the football_".
Kedua kalimat tersebut diubah menjadi bentuk @AMR dengan format logika.
Logika proposisi dari representasi @AMR pertama dapat dilihat pada @fig--first-logical-proposition.
Sedangkan bentuk logika proposisi untuk representasi kedua dapat dilihat pada @fig--second-logical-proposition.
Berdasarkan contoh tersebut, terdapat 6 cara untuk memasangkan variabel-variabel antara kedua @AMR tersebut.
Salah satu contoh pemasangan variabel-variabel tersebut adalah dengan memasangkan variabel `x`, `y`, `z` pada @AMR kedua dengan variabel `a`, `b`, `c` secara berturut-turut, sehingga didapatkan 4 buah logika preposisi yang sama, yaitu:
+ `instance(a, want-01)`,
+ `instance(b, boy)`,
+ `ARG0(a, b)`, dan
+ `ARG1(a, c)`.
@tab--smatch-matching menunjukkan semua kombinasi cara memasangkan variabel kedua @AMR tersebut.
Hasil skor @SMATCH diambil dari nilai F-Score tertinggi, yaitu 0.73.

#fig-img(
  image("first-logical-proposition.png", width: 40%),
  caption: [Logika proposisi untuk @AMR dari kalimat "_the boy wants to go_".],
) <fig--first-logical-proposition>

#fig-img(
  image("second-logical-proposition.png", width: 45%),
  caption: [Logika proposisi untuk @AMR dari kalimat "_the boy wants the football_".],
) <fig--second-logical-proposition>

#fig-tab(
  tablex(
    columns: 5,
    align: (x, y) => center,
    [*Pemetaan*],[*Match*],[*Precision*],[*Recall*],[*F1*],
    [x=a, y=b, z=c],[4],[4/5],[4/6],[0.73],
    [x=a, y=c, z=b],[1],[1/5],[1/6],[0.18],
    [x=b, y=a, z=c],[0],[0/5],[0/6],[0.00],
    [x=b, y=c, z=a],[0],[0/5],[0/6],[0.00],
    [x=c, y=a, z=b],[0],[0/5],[0/6],[0.00],
    [x=c, y=b, z=a],[2],[2/5],[2/6],[0.36],
    colspanx(4)[*Nilai F1 SMATCH*],(),(),(),[*0.73*],
  ),
  caption: [Kombinasi pasangan @AMR dan kalkulasi nilai F1 @SMATCH @cai2013.],
) <tab--smatch-matching>

Karena kedua @AMR ini memiliki variabel yang berbeda dan tidak ada informasi mengenai hubungan antar variabel yang ada, perlu dicari semua kemungkinan dari pemetaan variabel yang ada.
Dari seluruh pemetaan, nilai @SMATCH akan mengambil hasil yang memiliki nilai F1 tertinggi.
Untuk mengurangi waktu yang dibutuhkan dalam evaluasi tanpa menurunkan akurasi, dimanfaatkan metode hill-climbing.
Metode ini bekerja secara greedy dan tidak seoptimal bruteforce, namun bisa menghasilkan perhitungan yang cukup baik.

Selain evaluasi @SMATCH, ada varian metrik lain yang dapat digunakan untuk mengetahui kelebihan dan kekurangan dari berbagai aspek lain dari sebuah #t.amrparser @damonte2017.
Metrik-metrik tersebut adalah:
+ Unlabeled: Pendekatan perhitungan @SMATCH yang mengabaikan label pada relasi sehingga hanya label simpul saja yang dibandingkan.
+ No WSD: Menghapus semua _sense_ dari label simpul yang berupa _frame_ PropBank. Misalnya _sense_ `give-01` dan `give-02` akan dihitung sama.
+ Reentrancies: Hanya menghitung simpul-simpul yang memiliki _parent_ lebih dari satu.
+ SRL: Hanya menghitung triplet yang mengandung relasi `:ARGx`.
+ Concepts: Hanya menghitung pencocokan konsep pada tiap simpul.
+ NER: Hanya menghitung pencocokan konsep pada tiap simpul yang memiliki relasi `:name`.
+ Wikification: Hanya menghitung pencocokan konsep pada tiap simpul yang memiliki relasi `:wiki`.
+ Negation: Hanya menghitung pencocokan konsep pada tiap simpul yang memiliki relasi `:polarity`.
+ Frames: Hanya menghitung pencocokan konsep pada tiap simpul yang termasuk pada _frameset_ ProbBank.
