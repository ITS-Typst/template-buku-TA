#import "/globals.typ": *

== _Abstract Meaning Representation_ (AMR)

@AMR merupakan sebuah representasi kalimat yang memperhatikan semantik.
@AMR adalah graf berakar, berlabel, terarah, dan bersiklus yang terdiri dari satu kalimat utuh namun tidak boleh membentuk siklik.
Tujuan dari @AMR mengabstraksikan kalimat dari representasi sintaktiknya, di mana kalimat-kalimat yang memiliki pengertian yang sama seharusnya memiliki @AMR yang sama, walaupun tidak direpresentasikan dengan kalimat yang sama.
@AMR awalnya dirancang untuk kalimat berbahasa Inggris @banarescu2013.

Graf @AMR terdiri dari simpul yang berupa konsep dan sisi yang berupa relasi.
Simpul pada @AMR dapat berupa:
+ kata dalam Bahasa Inggris ("_boy_", "_possible_", "_team_")
+ _framesets_ ProbBank (`go-01`, `go-03`, `want-01`), atau
+ kata kunci spesial.
Kata kunci spesial dapat berupa:
+ tipe entitas (`date-entity`, `world-region`, dll.),
+ kuantitas (`monetary-quantity`, `distance-quantity`, dll.), atau
+ logika konjugasi (`and`, `or`, dll.).
@AMR menggunakan _framesets_ PropBank @kingsbury2002 secara ekstensif untuk merepresentasikan predikat yang ada dalam kalimat.
Predikat terdiri dari kata dasar predikat tersebut ditambahkan dengan nomor _sense_-nya, seperti _frame_ ProbBank `go-01` merupakan predikat "_go_" dengan nomor _sense_ `01`.
Predikat dengan nomor _sense_ yang berbeda berarti mempunyai makna yang berbeda.
Misalnya, kata "_go_" pada kalimat "_the boy wants to go_" memiliki arti aksi gerakan (_motion_) untuk bepergian yang didefinisikan pada _frame_ ProbBank `go-01`, sedangkan kata "_go_" pada kalimat "_Portfolio managers go after the highest rates._" memiliki arti aksi untuk mencapai sesuatu yang didefinisikan pada  _frame_ ProbBank `go-03`.

Sisi pada graf @AMR adalah relasi antar konsep yang dapat berupa:
+ argumen _frame_ ProbBank (`:arg0`, `arg1`, dll.),
+ relasi umum semantik (`:accompanier`, `:age`, `:beneficiary`, `:cause`, dll.),
+ relasi untuk kuantitas (`:quant`, `:unit,` `:scale`),
+ relasi untuk entitas tanggal (`:day`, `:month`, `:year`, dll.), atau
+ relasi untuk daftar (`:op1`, `:op2`, `:op3`, dll.).

Sebagai contoh, kalimat "_the boy wants to go_" dalam bentuk @AMR memiliki tiga konsep, yaitu:
+ "_boy_" sebagai sebuah kata dalam Bahasa Inggris.
+ "_wants_" sebagai sebuah predikat yang didefinisikan sebagai _frame_ ProbBank `want-01` karena kata tersebut pada kalimat tersebut memiliki arti sebuah keinginan (_desire_), sesuai pada definisi frame `want-01`.
  Konsep "_boy_" digunakan sebagai argumen pertama sebagai subjek yang melakukan aksi.
  Konsep `go-01` digunakan sebagai argumen kedua sebagai aksi yang ingin dilakukan.
+ "_go_" sebagai sebuah predikat yang didefinisikan sebagai _frame_ ProbBank `go-01` karena kata tersebut pada kalimat tersebut memiliki arti aksi gerakan (_motion_) untuk bepergian, sesuai pada definisi frame `go-01`.
  Konsep "_boy_" digunakan sebagai argumen pertama sebagai subjek yang melakukan aksi.

Dalam pembentukan graf dari kalimat, @AMR tidak mempedulikan urutan dan langkah.
Spesifikasi anotasi @banarescu2012abstract berisikan aturan-aturan untuk merepresentasikan berbagai macam kata, frasa, dan kalimat.
Pada panduan tersebut tidak terdapat aturan eksplisit mengenai langkah pembentukan @AMR dari suatu kalimat dan bagaimana urutan yang harus diikuti.
Hal ini mendorong peneliti untuk berpikir secara fleksibel mengenai hubungan antara kalimat dan maknanya.
Sebuah @AMR dapat dituliskan dalam format graf, penman, DFS, dan logika preposisi.
Contoh dari representasi graf tersebut dapat dilihat pada @tab--amr-representations.

#fig-tab(
  tablex(
    columns: (auto, 50%),
    align: (x, y) => if y == 0 or x > 0 {center} else {left},
    [*Nama representasi*],[*Bentuk representasi*],
    [Graf],image("amr-graph-example.svg"),
    [PENMAN],image("amr-penman-example.png"),
    [Logika Preposisi],image("amr-logic-example.png"),
  ),
  caption: [Contoh representasi graf @AMR dari kalimat "_the boy wants to go_".],
) <tab--amr-representations>
