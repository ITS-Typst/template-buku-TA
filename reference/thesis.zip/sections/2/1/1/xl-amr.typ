#import "/globals.typ": *

=== AMR _parsing Lintas Bahasa_

Sebuah @AMR merupakan graf dengan simpul yang merepresentasikan konsep dalam kalimat dan sisi yang merepresentasikan hubungan semantik antar kalimat.
Dataset @AMR yang cukup besar untuk dilatih berisikan pasangan kalimat berbahasa Inggris dengan graf @AMR.
Properti #t.linbhs dari @AMR di berbagai bahasa merupakan subjek yang sering dibahas.
#icite("banarescu2013") menyatakan bahwa @AMR bukanlah representasi lintas bahasa dan dapat dikategorikan menjadi jenis @AMR yang berbeda untuk anotasi dari bahasa yang berbeda.
@fig--amr-example merupakan contoh graf @AMR dengan pasangan kalimat Bahasa Inggris dan Italia.

#fig-img(
  image("amr-example.png", width: 50%),
  caption: [Contoh graf @AMR dengan pasangan kalimat Bahasa Inggris dan Italia @damonte2018.],
) <fig--amr-example>

Tujuan dari @AMR adalah untuk mengabstraksikan sintaks dari sebuah kalimat dengan tetap mempertahankan makna yang tersirat (semantik).
Sebagai konsekuensi, perbedaan frasa yang berbeda dari satu kalimat diharapkan untuk memberikan representasi @AMR yang identik.
Namun, hal ini tidak selalu berlaku untuk lintas bahasa.
Dua kalimat yang mengekspresikan makna yang sama dalam dua bahasa yang berbeda tidak menjamin untuk menghasilkan struktur @AMR yang identik @xue2014.
Dalam mengatasi permasalahan ini, #icite("damonte2018") mengusulkan dua metode yang berbeda.
+ Proyeksi anotasi.
  Setiap simpul pada graf @AMR dapat dilakukan _alignment_ dengan kata pada kalimat berbahasa Inggris.
  Dengan asumsi bahasa target memiliki struktur yang mirip dengan Bahasa Inggris, maka dapat dilakukan _alignment_ terhadap bahasa tersebut.
+ #t.Tnp.
  Pada metode ini digunakan sebuah mesin translasi untuk menerjemahkan kalimat dengan bahasa lain menjadi Bahasa Inggris.
  Hasil kalimat berbahasa Inggris tersebut kemudian diubah menjadi graf @AMR.
  Kualitas dari hasil graf @AMR tersebut bergantung pada kualitas mesin translasi yang digunakan.
  Metode #t.tnp digunakan _baseline_ @uhrig2021 untuk model #t.amrparser lintas bahasa seperti penelitian #icite("blloshmi2020").

#icite("blloshmi2020") mengusulkan skema dalam melakukan _training_ untuk #t.amrparsing #t.linbhs.
Ilustrasi skema pelatihan tersebut dapat dilihat pada @fig--xl-amr-schemes.
Skema-skema tersebut adalah sebagai berikut:
+ Zero-shot.
  Model dilatih pada kalimat berbahasa Inggris saja dengan mengandalkan fitur #t.multil, kemudian dievaluasi pada bahasa target.
+ Language-specific.
  Model dilatih pada kalimat berbahasa bahasa target, misal Bahasa Indonesia, kemudian dievaluasi pada bahasa target tersebut.
+ Bilingual.
  Model dilatih pada kalimat berbahasa Inggris dan bahasa target, kemudian dievaluasi pada bahasa tersebut.
+ Multilingual.
  Model dilatih pada kalimat-kalimat dengan berbagai macam bahasa, kemudian dievaluasi pada bahasa-bahasa tersebut.

#fig-img(
  image("schemes.png", width: 100%),
  caption: [Skema pelatihan untuk #t.amrparsing lintas bahasa @blloshmi2020.],
) <fig--xl-amr-schemes>
