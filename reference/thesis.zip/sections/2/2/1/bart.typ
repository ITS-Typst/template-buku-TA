#import "/globals.typ": *

=== Model Bahasa BART

BART dikembangkan sebagai model yang mampu melakukan denoising autoencoder yang memapping dokumen yang di-_masking_ terhadap dokumen originalnya @lewis2020.
BART diimplementasikan sebagai model berbasis transformer dengan bidirectional encoder dan left-to-right autoregressive decoder.
BART memiliki arsitektur _encoder_ seperti @BERT @devlin2019 dan _decoder_ seperti @GPT2 @radford2019.
BART @lewis2020 diimplementasikan sebagai model berbasis @seq2seq pada standar arsitektur Transformer @vaswani2017.
Arsitektur BART dapat dilihat pada @fig--bart-architecture.

#fig-img(
  image("bart-architecture.png", width: 50%),
  caption: [Arsitektur BART @lewis2020.],
) <fig--bart-architecture>

Tokenisasi yang dilakukan pada model BART berbasis sub-kata yang mengandung 2 tahap.
Tahap pertama yaitu mengubah teks menjadi daftar token-token.
Token-token tersebut dapat berupa sub-kata yang menggunakan algoritma Byte-Pair Encoding (BPE).
Tahap kedua yaitu mengubah daftar token-token tersebut menjadi token ID yang sesuai berdasarkan kosa kata.
Sebagai contoh sebuah teks "hello world!" diubah menjadi token-token "hello", "world", dan "!".
Token-token tersebut lalu diubah menjadi token ID 7592, 2088, dan 999.
Token ID tersebut kemudian dapat dibaca oleh layer _embedding_ pada _encoder_ untuk dilakukan inferensi.

BART dilatih untuk merekonstruksi teks original yang dilakukan 5 fungsi noising berikut ini:
+ Token masking: Token secara random diubah menjadi elemen _mask_.
+ Token deletion: Token secara random dihapus dari input.
+ Text Infilling: Teks spans secara random diubah menjadi token single _mask_.
+ Sentence permutation: Teks dibagi menjadi segmen-segmen lalu dipermutasi.
+ Document Rotation: Dokumen dirotasi untuk dimulai dengan token random.
Ilustrasi pelatihan BART tersebut dapat dilihat pada @fig--bart-tasks.

#fig-img(
  image("bart-tasks.png", width: 75%),
  caption: [_Task_ pelatihan BART @lewis2020.],
) <fig--bart-tasks>

BART juga dikembangkan untuk model #t.multil bernama mBART @liu2020.
mBART dikembangkan untuk 25 bahasa yang berbeda, namun tidak termasuk Bahasa Indonesia.
Kemudian mBART dikembangkan kembali untuk bahasa yang lebih banyak lagi oleh #icite("tang2020") untuk 50 bahasa yang berbeda, termasuk Bahasa Indonesia.
Model tersebut dinamakan #models.mbart-large.
Model #models.mbart-large memiliki 12 layer _encoder_ dan 12 layer _decoder_ dengan 1024 dimensi.
