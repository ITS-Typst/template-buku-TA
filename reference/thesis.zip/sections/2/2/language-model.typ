#import "/globals.typ": *

== Model Bahasa berbasis Transformer

Sebuah model bahasa adalah suatu jenis model statistik atau model mesin yang dirancang untuk memahami dan menghasilkan teks yang mirip dengan teks manusia.
Model bahasa berfokus pada pemrosesan bahasa alami dan bertujuan untuk mempelajari struktur, statistik, dan pola yang terdapat dalam bahasa manusia.

Transformer merupakan sebuah sequence-to-sequence model yang terdiri dari _encoder_ dan _decoder_ @vaswani2017.
Transformer bergantung sepenuhnya terhadap mekanisme atensi untuk menggambarkan ketergantungan global antara input dan output.
Model berbasis transformer dapat berjalan secara paralel sehingga dapat mempercepat proses _training_.

Salah satu pengembangan _encoder_ dari model transformer adalah @BERT.
@_BERT merupakan teknik machine learning berbasis transformer untuk _natural language processing_ yang dikembangkan oleh Google @devlin2019.
@_BERT memiliki kemampuan untuk memahami konteks dalam sebuah kalimat dan menggunakannya untuk menghasilkan hasil yang lebih akurat daripada model pembelajaran mesin sebelumnya.
@_BERT merupakan pengembangan komponen _encoder_ pada model transformer.
@_BERT dilatih terhadap dua _task_ yaitu _language modeling_ dan _next sentence prediction_.
Sebagai hasil dari proses pembelajaran ini adalah, @BERT mempelajari embedding kontekstual untuk kata-kata yang ada.

Dalam menangani _task_ yang memerlukan lebih dari satu bahasa, seperti mesin translasi, digunakan representasi #t.mwordem.
Model #t.multil dapat dibangun dengan menambahkan kosa kata dari bahasa lain dalam data _training_.
@_BERT juga dapat digunakan untuk menghasilkan #t.mwordem dengan dilatih menggunakan dataset yang terdiri dari 101 bahasa untuk menghasilkan #t.multil model bernama mBERT.
Terdapat variasi @BERT yang digunakan sebagai #t.mwordem yang tidak terikat ke bahasa apapun, yaitu @LABSE @feng2022.
@_LABSE berusaha merepresentasikan kalimat dalam bahasa yang berbeda-beda menjadi satu representasi yang sama.
