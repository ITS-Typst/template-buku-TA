#import "/globals.typ": *

=== @_XLM_

@_XLM menunjukkan sebuah teknik #t.pretraining lain untuk memanfaatkan korpus paralel.
@_XLM memanfaatkan kombinasi @MLM dan @TLM.
Teknik #t.pretraining @MLM mengikuti cara #t.pretraining @BERT, yaitu dengan melakukan _masking_ pada beberapa kata dari input.
Teknik #t.pretraining @TLM melakukan #t.concat antara dua kalimat dari bahasa yang berbeda.
Kalimat dari bahasa yang berbeda tersebut dianggap sebagai _next sentence_ pada model @BERT dengan mengulang kembali _position embeddings_ dari indeks awal kembali.
Ilustrasi #t.pretraining @XLM dapat dilihat pada @fig--xlm-pretraining.

#fig-img(
  image("xlm-pretraining.png", width: 100%),
  caption: [@_XLM #t.pretraining @conneau2019.],
) <fig--xlm-pretraining>
