#import "/globals.typ": *

=== _Graph Pre-training for AMR Parsing and Generation_ // @bai2022

@_PLM telah terbukti dapat melakukan _task_ #t.amrparsing dan generasi #t.AMRtoTEXT dengan baik.
Namun, @PLM umumnya dilatih pada data tekstual, sehingga tidak optimal untuk melakukan generasi data terstruktur seperti @AMR.
#icite("bai2022") memperbaiki permasalahan tersebut dengan menambahkan strategi #t.gpretraining pada model untuk mengintegrasikan informasi teks dan graf @AMR.
Model ini melinearisasi graf @AMR ke sekuens sehingga baik #t.amrparsing dan #t.AMRtoTEXT generation dapat dilakukan menggunakan model @seq2seq.
Model ini melakukan #t.gpretraining pada struktur @AMR menggunakan BART.

Tahapan _preprocessing_ dalam model ini mengadopsi penelitian #icite("bevilacqua2021"), yaitu _recategorization_ untuk mengurangi ukuran _vocab_ untuk menangani _sparsity_ data.
_Recategorization_ dilakukan dengan menghapus simpul _sense_, _link_ wiki, atribut polaritas, dan menganonimasi _named entity_.
Walaupun _recategorization_ menunjukkan kinerja yang kurang pada penelitian #icite("bevilacqua2021"), namun pada AMRBART tidak terjadi pengurangan kinerja.
Lemmatisasi juga dilakukan pada fase _preprocessing_.
Linearisasi graf menggunakan algoritma @DFS yang diadopsi dari penelitian #icite("bevilacqua2021").
Pembentukan graf @AMR hasil prediksi dilakukan pada tahapan _postprocessing_ dengan mengubah bentuk format @DFS menjadi bentuk format PENMAN.
Wikifikasi, pemberian _link_ pada atribut wiki, juga dilakukan menggunakan BLINK Entity Linker @wu2020.
Pengembalian atribut polaritas dilakukan dengan mengidentifikasi lemma yang bersifat negasi.

Model ini mengenalkan dua strategi _self-supervised training_ dalam melakukan #t.gpretraining model BART pada graf @AMR.
Dapat dilihat pada @fig--pre-training-strategies, strategi level #t.denoising simpul/sisi mendukung model untuk menangkap pengetahuan lokal mengenai simpul dan sisi.
Strategi #t.denoising level graf mengarahkan model untuk memprediksi sub-graf yang dapat memfasilitasi pembelajaran graf.
+ #t.Denoising level simpul/sisi.
  Pengaplikasian fungsi noise pada simpul dan sisi AMR untuk mengkonstruksi input graf yang kotor.
  Fungsi noise ini diimplementasikan dengan _masking_ 15% simpul dan 15% sisi di setiap graf.
+ #t.Denoising level sub-graf.
  _Task_ ini bertujuan untuk mengembalikan graf lengkap ketika diberikan sebagian dari graf.
  Metode ini menghilangkan sub-graf secara acak dari graf dan mengubahnya dengan token _mask_.

#fig-img(
  image("pre-training-strategies.png", width: 100%),
  caption: [Ilustrasi strategi #t.gpretraining: (1) #t.denoising level simpul/sisi (a->b); (2) #t.denoising level sub-graf (c->b) @bai2022.],
) <fig--pre-training-strategies>

Strategi #t.gpretraining (G.P.T.) dan #t.finetuning (F.T.) dapat dilihat pada @tab--amrbart-pt-ft-strategies.
$t$/$g$ merupakan teks/graf _original_.
$accent(t, hat)$/$accent(g, hat)$ merupakan teks/graf yang _noisy_ (hasil #t.denoising).
$accent(t, macron)$/$accent(g, macron)$ merupakan teks/graf yang hilang.
Token `<s>` dan `<g>` digunakan untuk membedakan informasi teks dan graf pada input.
#t.Gpretraining dilakukan dengan menghapus sebagian dari input teks/graf dengan teknik #t.denoising.
#t.Finetuning dilakukan dengan menghapus keseluruhan dari teks/graf yang dituju.
Pada _standard_ #t.gpretraining dan #t.finetuning, input berupa salah satu dari teks atau graf dan outputnya berupa teks atau graf yang dituju.
Namun, pada _unified_ #t.gpretraining dan #t.finetuning, input berupa kedua teks dan graf, dan outputnya berupa teks atau graf yang dituju.

#fig-tab(
  tablex(
    columns: 4,
    [*Fase*],[*_Task_*],[*Input*],[*_Output_*],
    rowspanx(2)[Std. G.P.T.],[$accent(t, hat) 2 t$],text(size: 0.9em)[`<s>x1,..[mask]..,xn</s>`],text(size: 0.9em)[`<s>x1,x2,...,xn</s>`],
    (),[$accent(g, hat) 2 g$],text(size: 0.9em)[`<g>g1,..[mask]..,gm</g>`],text(size: 0.9em)[`<g>g1,g2,...,gm</g>`],
    rowspanx(2)[Std. F.T.],[$g 2 t$],text(size: 0.9em)[`<g>g1,g2,...,gm</g>`],text(size: 0.9em)[`<s>x1,x2,...,xn</s>`],
    (),[$t 2 g$],text(size: 0.9em)[`<s>x1,x2,...,xn</s>`],text(size: 0.9em)[`<g>g1,g2,...,gm</g>`],
    rowspanx(4)[Unified G.P.T.],[$accent(t, hat) accent(g, macron) 2 t$],text(size: 0.9em)[`<s>x1,..[mask]..,xn</s>` \ `<g>[mask]</g>`],text(size: 0.9em)[`<s>x1,x2,...,xn</s>`],
    (),[$accent(t, macron) accent(g, hat) 2 g$],text(size: 0.9em)[`<s>[mask]</s>` \ `<g>g1,..[mask]..,gm</g>`],text(size: 0.9em)[`<g>g1,g2,...,gm</g>`],
    (),[$accent(t, hat) g 2 t$],text(size: 0.9em)[`<s>x1,..[mask]..,xn</s>` \ `<g>g1,g2,...,gm</g>`],text(size: 0.9em)[`<s>x1,x2,...,xn</s>`],
    (),[$t accent(g, hat) 2 g$],text(size: 0.9em)[`<s>x1,x2,...,xn</s>` \ `<g>g1,..[mask]..,gm</g>`],text(size: 0.9em)[`<g>g1,g2,...,gm</g>`],
    rowspanx(4)[Unified F.T.],[$accent(t, hat) accent(g, hat) 2 t$],text(size: 0.9em)[`<s>x1,..[mask]..,xn</s>` \ `<g>g1,..[mask]..,gm</g>`],text(size: 0.9em)[`<s>x1,x2,...,xn</s>`],
    (),[$accent(t, hat) accent(g, hat) 2 g$],text(size: 0.9em)[`<s>x1,..[mask]..,xn</s>` \ `<g>g1,..[mask]..,gm</g>`],text(size: 0.9em)[`<g>g1,g2,...,gm</g>`],
    (),[$accent(t, macron) g 2 t$],text(size: 0.9em)[`<s>[mask]</s>` \ `<g>g1,g2,...,gm</g>`],text(size: 0.9em)[`<s>x1,x2,...,xn</s>`],
    (),[$t accent(g, macron) 2 g$],text(size: 0.9em)[`<s>x1,x2,...,xn</s>` \ `<g>[mask]</g>`],text(size: 0.9em)[`<g>g1,g2,...,gm</g>`],
  ),
  caption: [Strategi #t.gpretraining (G.P.T.) dan #t.finetuning (F.T.) untuk pelatihan graf @bai2022.],
) <tab--amrbart-pt-ft-strategies>

Penggunaan teknik masking saat melakukan #t.gpretraining dapat meningkatkan kinerja model dalam melakukan #t.amrparsing maupun #t.AMRtoTEXT.
Pengaruh penggunaan teknik masking tersebut dapat dilihat pada @tab--exp-masking.
Ketika menggunakan semua kombinasi teknik masking, didapatkan kinerja @SMATCH dan @BLEU tertinggi, 83.6 dan 45.6 secara berturut-turut.
Model #t.amrparser tersebut juga memiliki kinerja terbaik dibandingkan dengan penelitian-penelitian sebelumnya, seperti yang terlihat pada @tab--bai2022-results.

#fig-tab(
  image("exp-masking.png", width: 70%),
  caption: [Pengaruh penggunaan teknik masking @bai2022.],
) <tab--exp-masking>

#fig-tab(
  image("results.png"),
  caption: [Hasil evaluasi model #t.amrparser pada AMR 2.0 dan AMR 3.0 @bai2022.],
) <tab--bai2022-results>
