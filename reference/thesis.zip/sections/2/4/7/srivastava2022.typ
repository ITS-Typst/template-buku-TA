#import "/globals.typ": *

=== _Trimming_ Model Transformer dengan hf-trim // @srivastava2022

Model berbasis Transformer dikembangkan oleh HuggingFace dengan menggunakan PyTorch.
Banyak model #t.multil yang mendukung puluhan bahasa dalam satu model.
Banyaknya dukungan bahasa tersebut membutuhkan ukuran kosa kata pada model dan waktu yang banyak dalam melakukan pelatihan dan inferensi model.
Beberapa model #t.multil digunakan hanya untuk beberapa kasus untuk bahasa tertentu saja, sehingga banyak bagian token pada kosa kata yang tidak akan digunakan.

#icite("srivastava2022") mengembangkan sebuah solusi dengan menghapus sebagian kosa kata yang tidak digunakan dari sebuah model berbasis Transformer tanpa mengurangi kinerjanya secara drastis.
Penghapusan sebagian kosa kata tersebut juga berarti menghapus sebagian _weight_ pada layer input dan _output_ dari bagian _encoder_ dan _decoder_ yang berkorespondensi dengan token-token yang dihapus.
Motivasinya adalah dengan menghapus sebagian besar kosa kata yang tidak digunakan dapat membebaskan sebagian memori dan dapat digunakan untuk ukuran _batch_ yang lebih besar atau untuk memuat model yang seharusnya terlalu besar untuk memori.
Salah satu contoh terbaik adalah untuk model #t.multil, yang sering digunakan untuk beberapa bahasa saja.
Walaupun begitu, penghapusan beberapa token dari kosa kata dapat mengurangi kinerja sedikit, seperti yang dilaporkan pada #rawlink("https://github.com/pytorch/fairseq/issues/2120#issuecomment-661509060"), yaitu berkurangnya skor BLEU kurang dari 1 poin pada model mBART.
Solusi tersebut dikembangkan dalam sebuah program bernama #t.hf-trim yang dapat diakses pada #rawlink("https://github.com/IamAdiSri/hf-trim").

Cara menginstall program #t.hf-trim sebagai _package_ pada Python dapat dilihat pada @code--install-hf-trim.
Contoh Contoh penggunaan #t.hf-trim untuk menghapus sebagian kosa kata Model mT5 dapat dilihat pada @code--hf-trim-example.

#fig-code(
  ```bash
$ git clone https://github.com/IamAdiSri/hf-trim
$ cd hf-trim
$ pip install .
```, //$
  caption: [Cara install #t.hf-trim @srivastava2022.],
) <code--install-hf-trim>

#fig-code(
  ```python
from transformers import MT5Config, MT5Tokenizer, MT5ForConditionalGeneration
from hftrim.TokenizerTrimmer import TokenizerTrimmer
from hftrim.ModelTrimmers import MT5Trimmer

data = [
  " UN Chief Says There Is No Military Solution in Syria",
  "Şeful ONU declară că nu există o soluţie militară în Siria"
]

# load pretrained config, tokenizer and model
config = MT5Config.from_pretrained("google/mt5-small")
tokenizer = MT5Tokenizer.from_pretrained("google/mt5-small")
model = MT5ForConditionalGeneration.from_pretrained("google/mt5-small")

# trim tokenizer
tt = TokenizerTrimmer(tokenizer)
tt.make_vocab(data)
tt.make_tokenizer()

# trim model
mt = MT5Trimmer(model, config, tt.trimmed_tokenizer)
mt.make_weights(tt.trimmed_vocab_ids)
mt.make_model()
```,
  caption: [Contoh penggunaan #t.hf-trim untuk menghapus sebagian kosa kata Model mT5 @srivastava2022.],
) <code--hf-trim-example>
