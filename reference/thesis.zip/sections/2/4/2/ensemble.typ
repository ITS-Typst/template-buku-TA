#import "/globals.typ": *

=== Augmentasi _Silver Dataset_ AMR

Kenaikan kinerja dari #t.amrparsing dari penelitian-penelitian sebelumnya tidak lagi meningkat secara signifikan @lee2022.
Ini dikarenakan efek dari self-learning dan augmentasi _silver_ data mulai berkurang.
Untuk mengatasi hal tersebut, #icite("lee2022") mengusulkan untuk menggabungkan teknik _ensemble_ berbasis @SMATCH @hoang2021 dengan _ensemble distillation_ untuk menghasilkan _silver_ data berkualitas tinggi.

Teknik _ensemble_ yang diusulkan oleh #icite("hoang2021") bernama Algoritma Graphene dapat dilihat pada @fig--graph-ensemble-example.
Ide utamanya adalah dengan memperbaiki sebuah pivot graf berdasarkan graf yang dihasilkan oleh parser lain.
Dari pivot graf, dilakukan _voting_ untuk menghitung jumlah simpul dan sisi graf yang berkorelasi.
Setelah dilakukan _voting_, dipilih simpul dan sisi yang memiliki jumlah voting terbesar sebagai hasil akhir graf tersebut.
Hal ini dilakukan berulang kali untuk masing-masing graf sebagai pivot awal.

#fig-img(
  image("graph-ensemble-example.png", width: 100%),
  caption: [Ilustrasi teknik _ensemble_ @hoang2021.],
) <fig--graph-ensemble-example>

#icite("lee2022") mengusulkan sebuah kerangka kerja untuk melakukan augmentasi data @AMR.
Ilustrasi kerangka kerja tersebut dapat dilihat pada @fig--silver-data-generation-framework.
Dengan keterbatasan jumlah dataset yang dipunya untuk melatih model #t.linbhs, kerangka kerja ini menghasilkan lebih banyak pasangan graf @AMR dan kalimat dengan bahasa target.
Teknik-teknik yang digunakan untuk menghasilkannya adalah sebagai berikut:
+ Kalimat berbahasa Inggris dari dataset @AMR ditranslasi menjadi bahasa target.
+ Graf @AMR dari dataset @AMR dilakukan _parsing_ menjadi kalimat Bahasa Inggris untuk mendapatkan sebuah alternatif kalimat berbahasa Inggris.
  Dari kalimat alternatif tersebut dilakukan translasi menjadi bahasa target.
+ Kalimat-kalimat dari dataset kumpulan kalimat berbahasa Inggris tak berlabel ditranslasi menjadi bahasa target dan dilakukan _parsing_ menjadi graf @AMR menggunakan teknik _ensemble_ dengan 5 model #t.amrparser.

#fig-img(
  image("silver-data-generation-framework.png", width: 100%),
  caption: [Kerangka kerja untuk melakukan augmentasi pasangan data @AMR dan kalimat berbahasa Inggris untuk menghasilkan _silver_ data @lee2022.],
) <fig--silver-data-generation-framework>

#icite("lee2022") menggunakan teknik augmentasi dengan 5 model #t.amrparser untuk _ensemble_: Action-Pointer @zhou2021amr, Structured-BART @zhou2021structure, SPRING1 @bevilacqua2021, SPRING2 @bevilacqua2021, dan AMRBART @bai2022.
Hasil _silver dataset_ dari sekitar 90,000 data mencapai sekitar 219,000.
Augmentasi dataset tersebut dapat meningkatkan kinerja model #t.amrparser dari nilai @SMATCH 83.6 menjadi 84.3 (+#print-number(84.3-83.6, d: 1)).
