#import "/globals.typ": *

=== Peringkasan Abstraktif Multidokumen Menggunakan Abstract Meaning Representation untuk Bahasa Indonesia // @severina2019

Penelitian oleh #icite("severina2019") membahas mengenai pembangunan sistem peringkasan secara abstraktif dari dokumen berbahasa Indonesia dengan memanfaatkan AMR.
Pendekatan yang digunakan adalah #t.amrparsing yang memanfaatkan aturan dan kamus untuk membangun graf AMR berbahasa Indonesia dari teks berbahasa Indonesia.
Aturan pembangunan graf tersebut adalah sebagai berikut:
+ Simpul akar graf AMR yang dihasilkan ditentukan dengan _dependency parser_.
+ ARG0 dan ARG1 dari suatu predikat ditentukan dengan melihat apakah predikat merupakan kata kerja aktif atau pasif.
  Argumen akan diisi dengan subjek dan objek dari kata kerja terkait.
+ Keterangan dari predikat akan menjadi ARG2.

Teknik #t.amrparsing ini masih terbatas dengan banyak jumlah relasi ARG hanya sebanyak 3 buah.
Konsep pada @AMR yang dihasilkan masih berupa predikat yang diberi label "_-01_" di belakangnya dikarenakan PropBank berbahasa Indonesia masih belum ada.
Teknik evaluasi yang digunakan pada penilitian ini tidak menggunakan @SMATCH, namun menggunakan ukuran akurasi kemunculan simpul pada @AMR yang dihasilkan dibandingkan dengan referensinya.
