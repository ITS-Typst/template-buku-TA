#import "/globals.typ": *

=== Pembangkitan Abstract Meaning Representation Lintas Bahasa dari Kalimat Berbahasa Indonesia // @putra2022

Penelitian #icite("putra2022") melakukan #t.amrparsing dari kalimat berbahasa Indonesia dengan pendekatan cross lingual menggunakan dataset berkualitas _silver_ dan _gold_.
Pada pembangkitan ini, dilakukan pemilihan kalimat berdasarkan kedekatan semantiknya menggunakan #t.cossim sehingga kalimat dengan kinerja rendah dapat dikeluarkan terlebih dahulu dan mengurangi gap kinerja model.
Sumber daya yang digunakan dalam penelitian ini adalah #t.mwordem Numberbatch yang memiliki #t.wordem untuk bahasa Indo-Malay dan Inggris.
Untuk meningkatkan efisiensi dari #t.wordem tersebut, beberapa karakter Cina dan Arab yang tidak muncul dalam dataset AMR 2.0 dihapus.
Untuk sumber daya contextual #t.mwordem, digunakan beberapa alternatif berupa mBERT @devlin2019, XLM-R @conneau2019, dan mT5 @xue2021.

Gambaran keseluruhan sistem rancangan solusi dapat dilihat pada @fig--solution-diagram.
Tahapan yang dilakukan adalah sebagai berikut:
+ Kontruksi korpus sebagai dataset yang dibutuhkan.
+ Pelatihan model #t.amrparsing lintas bahasa.
+ Inferensi kalimat berbahasa Indonesia menjadi graf @AMR berbahasa Inggris.

#fig-img(
  image("solution-diagram.png", width: 55%),
  caption: [Gambaran keseluruhan sistem rancangan solusi pembangunan model #t.linbhs untuk Bahasa Indonesia @putra2022.],
) <fig--solution-diagram>

Skema model pelatihan #t.linbhs #t.amrparsing menggunakan skema yang diusulkan oleh #icite("blloshmi2020"), yaitu _zero-shot_, spesifik bahasa, dan bilingual.
@fig--training-schemas menunjukkan tiga skema pelatihan tersebut.
_Zero-shot_ hanya menggunakan kalimat berbahasa Inggris saja sebagai input model dan mengandalkan #t.mwordem untuk memahami konteks Bahasa Indonesia.
_Language-specific_ menggunakan kalimat berbahasa Indonesia saja sebagai input model.
Bilingual menggunakan kalimat berbahasa Inggris dan Indonesia sebagai input model yang kemudian dievaluasi ke Bahasa Indonesia.

#fig-img(
  image("training-schemas.png", width: 75%),
  caption: [Model pelatihan #t.linbhs untuk Bahasa Indonesia: (a) _zero-shot_, (b) spesifik bahasa, dan (c) bilingual @putra2022.],
) <fig--training-schemas>

Hasil eksperimen pada penelitian #icite("putra2022") menunjukkan bahwa skema bilingual menghasilkan kinerja model #t.amrparser terbaik dibandingkan yang lainnya.
Hal ini dikarenakan menggunakan tambahan kalimat Bahasa Inggris dari dataset AMR 2.0 dapat menambah _instance_ untuk model mengenalkan pola kalimat yang lebih tidak formal dibandingkan skema lainnya @putra2022.

Dataset yang digunakan #icite("putra2022") adalah korpus paralel PANL-BPPT dan _gold dataset_ AMR 2.0 yang kemudian dibangun _silver dataset_ dari dataset tersebut.
_Silver dataset_ yang dibangun oleh #icite("putra2022") merupakan pasangan data <`ID`, `EN`, `AMR`> yang terdiri dari: kalimat berbahasa Indonesia (`ID`), kalimat berbahasa Inggris (`EN`), dan graf AMR berbahasa Inggris (`AMR`).
Dataset tersebut dibangun dari korpus paralel PANL-BPPT <`ID`, `EN`> dengan melakukan #t.amrparsing bagian kalimat Bahasa Inggris (`EN`) ke @AMR Bahasa Inggris (`AMR`), dan dari AMR 2.0 <`EN`, `AMR`> dengan mentranslasikan kalimat Bahasa Inggris (`EN`) ke Bahasa Indonesia (`ID`).

Proses evaluasi pada penelitian ini dilakukan dengan pelaksanaan inferensi pada kalimat berbahasa Indonesia dari _gold dataset_ untuk menghasilkan @AMR berbahasa Inggris.
Dari graf @AMR ini akan dilakukan perhitungan skor @SMATCH dengan membandingkannya dengan graf @AMR _gold_.
Konfigurasi model #t.amrparsing lintas bahasa yang memiliki skor @SMATCH terbaik adalah dengan #t.mwordem dari @PLM mT5 dengan skor @SMATCH 51.0.
Namun teknik _baseline_ _translate-and-parse_ masih memiliki skor @SMATCH yang lebih tinggi, yaitu 62.5.

#icite("putra2022") juga melakukan evaluasi pada salah satu _downstream task_, yaitu #t.deop.
#icite("putra2022") menggunakan @SMATCH sebagai _threshold_ penentu prediksi klasifikasi _task_ tersebut.
Dibandingkan dengan @AMR Indonesia, #t.amrparsing lintas Bahasa Indonesia-Inggris memiliki kinerja lebih baik.
Skor F1 untuk #t.amrparser lintas bahasa adalah 73.8, sedangkan untuk @AMR Indonesia adalah 71.9.
