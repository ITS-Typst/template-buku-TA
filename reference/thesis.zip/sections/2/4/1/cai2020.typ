#import "/globals.typ": *

=== AMR Parsing via Graph-sequence Iterative Inference // @cai2020

Pada tingkat dasar, pendekatan #t.amrparsing dapat dikategorikan menjadi dua kelas, yaitu dua tahap _parsing_ dan satu tahap _parsing_ @cai2020.
Pada pendekatan dua tahap _parsing_ digunakan desain _pipeline_ untuk identifikasi keseluruhan konsep, lalu diikuti dengan prediksi relasi antar hasil prediksi konsep.
Pada pendekatan satu tahap _parsing_ dikategorikan menjadi tiga jenis, yaitu _parsing_ berbasis transisi, _parsing_ berbasis @seq2seq, dan _parsing_ berbasis graf.
Pendekatan satu tahap jenis _parsing_ berbasis transisi dilakukan dengan memproses kalimat dari kiri ke kanan dan membangun grafik secara bertahap dengan secara bergantian memasukkan simpul atau sisi baru.
Pendekatan satu tahap jenis _parsing_ berbasis @seq2seq dengan melihat _parsing_ sebagai transduksi urutan linear ke urutan linear juga dengan memanfaatkan linearisasi grafik AMR.
Pendekatan satu tahap jenis _parsing_ berbasis graf di mana setiap langkah waktu, simpul baru beserta koneksinya ke simpul yang ada diputuskan bersama secara berurutan maupun paralel.
@fig--partially-constructing-amr-graph merupakan contoh proses pembentukan graf @AMR dengan pendekatan satu tahap jenis _parsing_.

#fig-img(
  image("partially-constructing-amr-graph.png", width: 50%),
  caption: [Pembangunan sebuah graf @AMR dari subgraf @AMR yang sebagian terbentuk @cai2020.],
) <fig--partially-constructing-amr-graph>

#icite("cai2020") mengusulkan pendekatan #t.amrparsing via _graph-sequence iterative inference_ yang meniru proses manusia dalam melakukan deduksi graf semantik dari suatu kalimat.
Pendekatan ini dimulai dari graf kosong yang memanjang secara iteratif dari simpul ke simpul.
Ilustrasi pendekatan ini dapat dilihat pada @fig--dual-graph-sequence-iterative-inference.

#fig-img(
  image("dual-graph-sequence-iterative-inference.png", width: 100%),
  caption: [Ilustrasi dari pendekatan _graph-sequence iterative inference_ untuk #t.amrparsing @cai2020.],
) <fig--dual-graph-sequence-iterative-inference>
