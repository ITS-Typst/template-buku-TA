#import "/globals.typ": *

== _Bilingual Evaluation Understudy_ (BLEU)

@BLEU merupakan sebuah algoritma untuk mengevaluasi kualitas sebuah kalimat yang telah ditranslasi dari suatu bahasa tertentu ke bahasa lain @papineni2002.
Kualitas tersebut ditentukan dengan membandingkan hasil keluaran mesin translasi dengan hasil translasi manusia dengan anggapan semakin mendekati hasil translasi manusia, semakin baik kualitasnya.
@BLEU merupakan salah satu metrik pertama yang mengklaim korelasi tinggi dengan penilaian manusia dalam kualitas mengevaluasi, dan masih tetap menjadi metrik yang paling terkenal dan tidak mahal komputasinya.

Nilai @BLEU berada di antara 0 dan 1.
Nilai ini sebagai indikasi kemiripan teks kandidat dengan teks referensi dengan semakin tinggi nilai semakin mirip.
Hanya sedikit translasi yang menghasilkan nilai 1, karena itu berarti teks tersebut sama persis dengan teks referensi.
Karena itu, hasil translasi yang bagus tidak harus mendapatkan nilai 1.
Menambahkan referensi lebih dari satu juga dapat meningkatkan kualitas dari penilaian.

#let m-n-gram-prec = [_modified n-gram precision_]
#let M-n-gram-prec = [_Modified n-gram precision_]
#let brev-pen = [_brevity penalty_]
#let Brev-pen = [_Brevity penalty_]

Perhitungan skor @BLEU menggunakan kalkulasi #m-n-gram-prec dan #brev-pen.
#M-n-gram-prec menghitung banyak n-substring pada teks referensi yang muncul di teks kandidat.
#Brev-pen digunakan karena #m-n-gram-prec menghasilkan nilai yang tinggi apabila teks kandidat memiliki semua n-gram pada teks referensi, namun dengan jumlah yang sedikit.
Perhitungan #brev-pen adalah $"exp"(-max(0,1-r"/"c))$ dengan $r$ merupakan panjang teks referensi dan $c$ merupakan panjang teks kandidat.
Kalkulasi @BLEU berupa $"BLEU" = "BP" dot "exp"(sum^N_(n=1) w_n "log" p_n)$ dengan keterangan:
#[
  #set list(indent: 1em)
  - $"BP"$ = #brev-pen
  - $N$ = n maksimum yang digunakan pada #m-n-gram-prec
  - $w_n$ = bobot untuk setiap n-gram dengan total = 1
  - $p_n$ = #m-n-gram-prec
]

Contoh perhitungan @BLEU untuk hasil parafrase kalimat "The guard arrived late because it was raining" dengan referensi "The guard arrived late because of the rain" adalah sebagai berikut.
+ Token 1-gram yang cocok: "The", "guard", "arrived", "late", "because".
  Hasil presisi 1-gram ($p_1$): 5/8.
+ Token 2-gram yang cocok: "The guard", "guard arrived", "arrived late", "late because".
  Hasil presisi 2-gram ($p_2$): 4/7.
+ Token 3-gram yang cocok: "The guard arrived", "guard arrived late", "arrived late because".
  Hasil presisi 3-gram ($p_3$): 3/6.
+ Token 4-gram yang cocok: "The guard arrived late", "guard arrived late because".
  Hasil presisi 4-gram ($p_4$): 2/5.
+ #Brev-pen: $"BP" = "exp"(-max(0,1-8/8)) = "exp"(0) = 1$
+ Skor @BLEU: $"BLEU" = "BP" dot "exp"((log p_1 + log p_2 + log p_3 + log p_4)/4) = 0.52$
