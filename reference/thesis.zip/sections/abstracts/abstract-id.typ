#import "/globals.typ": *

#let terms = ([_abstract meaning representation_], [#t.linbhs], [#t.deop], [_parsing_])

#let body = [
  _Abstract meaning representation_ (AMR) merupakan salah satu bentuk representasi dari sebuah kalimat yang memperhatikan semantik.
  #t.amrparser untuk kalimat berbahasa Indonesia telah dikembangkan untuk monolingual dan bilingual.
  Anotasi pada AMR Bahasa Indonesia masih memiliki konsep dan relasi yang terbatas sehingga AMR Bahasa Inggris digunakan.
  Pendekatan #t.linbhs mengubah kalimat berbahasa Indonesia menjadi AMR berbahasa Inggris.
  Model AMR parsing terbaik saat ini berbasis model bahasa BART yang disebut AMRBART dengan menggunakan teknik #t.gpretraining.
  Model BART untuk multilingual, mBART, dibutuhkan dalam melakukan #t.amrparsing #t.linbhs.
  Model mBART membutuhkan waktu yang lama dan memori yang besar untuk dilakukan pelatihan model.
  Data latih yang ada masih belum dilakukan evaluasi dan usaha dalam meningkatkan jumlah data dan kualitasnya.
  Metode pelatihan bilingual belum memanfaatkan keterkaitan antara kalimat berbahasa Indonesia dan kalimat berbahasa Inggris.
  Pada penelitian ini, dibangun sebuah #t.amrparser #t.linbhs untuk melakukan _parsing_ kalimat berbahasa Indonesia ke AMR Bahasa Inggris.

  Model #t.amrparser #t.linbhs untuk Bahasa Indonesia dibangun dengan menggunakan #t.gpretraining dengan model mBART.
  Dilakukan pemotongan kosa kata sesuai dataset latih untuk mengurangi waktu dan memori yang dibutuhkan saat melakukan pelatihan model.
  Model dilatih dengan dua macam teknik pelatihan, yaitu bilingual dan #t.concat.
  Pembentukan dataset latih yang dapat menghasilkan kinerja terbaik ditentukan dengan teknik augmentasi dan filtrasi dari Dataset AMR 2.0 dan AMR 3.0.
  Pada penelitian ini, dilakukan 3 tujuan eksperimen, yaitu #inline-list(
    [melakukan validasi pada model yang dilakukan pemangkasan sebagian dari kosa kata model],
    [penentuan teknik pelatihan antara penggunaan #t.concat atau tidaknya],
    [penentuan jenis pembentukan dataset yang terbaik],
    last: [serta],
  ).
  Eksperimen dilakukan dengan metrik SMATCH pada dataset AMR 3.0 bagian data validasi menggunakan #t.opus-mt untuk menghasilkan pasangan kalimat Bahasa Indonesia.
  Model kemudian diuji untuk _task_ #t.amrparsing #t.linbhs pada data uji AMR 3.0 dan #t.deop pada dataset WReTE dengan klasifikasi berdasarkan nilai SMATCH.

  Berdasarkan hasil eksperimen, terdapat 3 hal yang dapat disimpulkan, yaitu: #inline-list(
    [pemangkasan sebagian dari kosa kata model dapat mempercepat waktu pelatihan tanpa mengurangi kinerja secara drastis],
    [teknik pelatihan dengan #t.concat dapat meningkatkan kinerja model],
    [dataset AMR 3.0 dengan augmentasi dan filtrasi menghasilkan model dengan kinerja terbaik],
  ).
  Model terbaik dari eksperimen tersebut diuji dan memiliki kinerja SMATCH #print-number(tests-formatted.ours.at(0), d: 1).
  Kinerja tersebut dapat mengalahkan model-model pada penelitian sebelumnya.

  Pengujian pada _task_ #t.deop pada Dataset WReTE menghasilkan kinerja yang lebih baik dari model #t.amrparser sebelumnya pada data validasi, yaitu dengan skor F1 #print-number(para-vals.ours.at(3), d: 3).
  Lalu pengujian pada data uji menghasilkan kinerja skor F1 #print-number(para-tests.ours.at(3), d: 3).
  Namun belum dapat melampaui kinerja dari model _encoder_ seperti _fine-tuned_ mBERT dan _fine-tuned_ IndoBERT-lite-large-p2 dari IndoNLU dengan skor F1 #print-number(para-tests.mbert.at(3), d: 3) dan #print-number(para-tests.indobert.at(3), d: 3) secara berturut-turut.
]
