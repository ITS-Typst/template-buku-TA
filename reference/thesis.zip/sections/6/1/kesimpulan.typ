#import "/globals.typ": *

== Kesimpulan

Terdapat beberapa hal yang dapat disimpulkan dari penelitian ini, yaitu:

+ Kinerja AMR parser #t.linbhs untuk kalimat berbahasa Indonesia menjadi graf AMR berbahasa Inggris dapat ditingkatkan dengan menggunakan model AMRBART dengan metode pelatihan konkatenasi serta melakukan augmentasi dan filtrasi pada data latih @AMR Bahasa Inggris.

+ Pada pengujian model #t.amrparser #t.linbhs dari kalimat berbahasa Indonesia menjadi @AMR Bahasa Inggris, didapatkan nilai @SMATCH sebesar #print-number(tests-formatted.ours.at(0), d: 1) pada data uji AMR 2.0.

+ Pengujian pada task #t.deop dengan metode pembandingan nilai @SMATCH dari kedua kalimat menghasilkan kinerja yang lebih baik dari model #t.amrparser sebelumnya, yaitu dengan skor F1 #print-number(para-vals.ours.at(3), d: 3) pada data validasi dan #print-number(para-tests.ours.at(3), d: 3) pada data uji.
  Namun belum dapat melampaui kinerja dari model _fine-tuned_ mBERT dengan skor F1 #print-number(para-tests.mbert.at(3), d: 3) dan _fine-tuned_ IndoBERT-lite-large-p2 dari IndoNLU dengan skor F1 #print-number(para-tests.indobert.at(3), d: 3).
