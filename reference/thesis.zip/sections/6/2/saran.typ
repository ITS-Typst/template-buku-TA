#import "/globals.typ": *

== Saran

Saran yang dapat diberikan untuk pengembangan lebih lanjut antara lain:

+ Menggunakan model multilingual lain dengan teknik pelatihan yang sama, misal menggunakan model XLM-R, mT5, dan lain-lain.

+ Membangun sebuah model multilingual BART untuk Bahasa Inggris dan Bahasa Indonesia yang dapat digunakan untuk berbagai macam task #t.linbhs untuk Bahasa Indonesia sehingga tidak terbatas pada kosa kata dataset latih saja.

+ Meningkatkan kualitas translasi dengan menggunakan mesin translasi lain untuk meningkatkan kinerja #t.amrparsing.
  Tranlasi ketika membangun dataset latih maupun ketika inferensi.
