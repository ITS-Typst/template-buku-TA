#import "/globals.typ": *

== Analisis Masalah

//~ Model Trimming
Model AMRBART @bai2022 merupakan model #t.sota saat ini yang dibangun untuk #t.amrparsing dan #t.AMRtoTEXT untuk Bahasa Inggris.
Saat ini belum dikembangkan sebuah model #t.amrparsing #t.linbhs untuk Bahasa Indonesia berdasarkan model AMRBART.
Pengembangan AMRBART untuk #t.linbhs memerlukan model BART yang #t.multil dalam memahami kalimat Bahasa Indonesia.
Model #models.mbart-large merupakan satu-satunya model BART yang memiliki Bahasa Inggris dan Bahasa Indonesia dalam kosa kata-nya yang berukuran #print-number(vocab-counts.mbart-large) token.
Namun terdapat banyak kosa kata yang tidak akan digunakan untuk #t.linbhs #t.amrparsing Bahasa Indonesia, seperti Bahasa Arab, Cina, Jepang, dan lain-lain.
Karena banyak kosa kata tersebut, parameter Model #models.mbart-large menjadi sangat banyak dan pelatihan akan membutuhkan waktu yang lama.

//~ Dataset Augmentation
Dataset _training_ yang tersedia untuk #t.amrparsing #t.linbhs sangat terbatas.
Dataset untuk Bahasa Indonesia yang pernah dibangun sebelumnya adalah dataset `trans` dan `par` dari penelitian #icite("putra2022").
Dataset yang dibangun tersebut belum dilakukan evaluasi untuk mengetahui kualitasnya dan perlu ditingkatkan kualitasnya.

//~ Concatenation
Dataset untuk #t.amrparsing #t.linbhs untuk Bahasa Indonesia terdiri dari Kalimat Bahasa Indonesia, Kalimat Bahasa Inggris, dan graf @AMR.
Metode _training_ #t.linbhs terbaik untuk #t.amrparsing adalah metode bilingual @putra2022.
Metode bilingual tidak memanfaatkan keterkaitan antara kalimat berbahasa Indonesia dan kalimat berbahasa Inggris karena setiap kalimat tersebut digunakan sebagai data pelatihan yang terpisah sehingga keterkaitan tersebut belum digunakan secara maksimal.
