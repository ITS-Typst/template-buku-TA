#import "/globals.typ": *

== Rancangan Solusi

Model berbasis Transformer versi #t.multil dapat digunakan sebagai model @seq2seq untuk melakukan #t.amrparsing #t.linbhs.
Model yang dapat digunakan tersebut seperti BART, XLM-R, mT5, dan lain-lain.
Pada penelitian ini digunakan Model mBART sebagai model @seq2seq tersebut sebagai pengganti Model BART pada penelitian #icite("bai2022").
Model mBART yang tersedia yang digunakan adalah Model #models.mbart-large.

//~ Model Trimming
Model #models.mbart-large memiliki kosa kata untuk 50 bahasa dengan ukuran kosa kata-nya adalah 250,054.
Jumlah kosa kata dari Model #models.mbart-large dapat dikurangi berdasarkan data latih yang akan dibangun.
Setiap data pada data latih ditokenisasi menjadi token sesuai pada kosa kata pada Model #models.mbart-large.
Dari semua token tersebut, dibuat sebuah himpunan token yang akan digunakan sebagai kosa kata yang baru.
Lalu kosa kata dan pasangan _weight_ pada _encoder_ dan _decoder_ dari Model #models.mbart-large dipotong menjadi sesuai himpunan token tersebut.
Kosa kata model tersebut akan terbatas pada token-token yang ada pada data latih, sehingga tidak terjamin ada pada data test.
Hasil model setelah dikurangi jumlah kosa kata tersebut akan direferensikan dengan Model #models.mbart-trimmed.

//~ General Dataset Construction
Pada masalah kurangnya jumlah dataset yang digunakan sebagai data latih model, dibangun kumpulan dataset berkualitas _silver_ untuk pelatihan model #t.amrparsing lintas bahasa.
Diagram alur keseluruhan proses konstruksi Dataset Par, Train, Dev, dan Test dapat dilihat pada @fig--dataset-construction.
Alur proses konstruksi dataset berkualitas _silver_ mengikuti kerangka kerja augmentasi data oleh #icite("lee2022").

#fig-img(
  image("thesis-all-datasets.svg"),
  caption: [Diagram alur untuk konstruksi dataset Par, Train, Dev, dan Test dari korpus paralel dan dataset AMR.],
) <fig--dataset-construction>

//~ Dataset Par
Korpus paralel PANL-BPPT dan IWSLT17 digunakan sebagai dataset pasangan kalimat Bahasa Inggris dan Bahasa Indonesia.
Kalimat berbahasa Inggris dari korpus paralel diubah menjadi graf @AMR.
Model #t.amrparsing yang digunakan adalah teknik _ensembling_ dari 5 model #t.sota @lee2022.
Hasil graf @AMR yang dihasilkan akan digunakan sebagai dataset latih berkualitas _silver_.
Diagram alur untuk konstruksi Dataset Par dari korpus paralel dapat dilihat pada @fig--dataset-par-silver-construction.

#fig-img(
  image("thesis-dataset-par.svg", width: 50%),
  caption: [Diagram alur untuk konstruksi Dataset Par dari korpus paralel.],
) <fig--dataset-par-silver-construction>

//~ Dataset Train
Dataset @AMR berkualitas _gold_ yang digunakan adalah Dataset AMR 3.0 (LDC2020T02).
Augmentasi data untuk konstruksi dataset berkualitas _silver_ mengambil bagian data latih dari AMR 3.0 yang direferensikan dengan Dataset Train.
Kalimat berbahasa Inggris dari dataset @AMR tersebut diubah menjadi kalimat berbahasa Indonesia dengan menggunakan mesin translasi.
Model mesin translasi yang digunakan adalah model #t.opus-mt @tiedemann2020.
Graf @AMR juga dilakukan _parsing_ menjadi kalimat berbahasa Inggris (#t.AMRtoTEXT) untuk menambah jumlah variasi pasangan dataset.
Model untuk melakukan #t.AMRtoTEXT yang digunakan adalah AMRBART @bai2022.
Kalimat berbahasa Inggris hasil _parsing_ tersebut juga diubah menjadi kalimat berbahasa Indonesia dengan menggunakan mesin translasi.
Maka akan terdapat dua pasangan kalimat berbahasa Inggris dan Indonesia untuk satu buah graf @AMR.

//~ Quality measurement and filtration of Train Dataset
Dataset Train tersebut kemudian dilakukan filtrasi dengan algoritma 1-NN dengan #t.cossim sebagai fungsi jarak antar representasi kalimatnya.
Algoritma kNN berguna untuk menghindari potensi hasil #t.cossim yang baik, walaupun bukan translasi yang benar @artetxe2019margin.
Dataset tersebut dihitung kualitasnya menggunakan rata-rata #t.cossim antara kalimat berbahasa Inggris dan kalimat berbahasa Indonesia-nya.
Kualitas kalimat alternatif dan translasi juga dihitung dengan skor @BLEU antara kalimat berbahasa Inggris dengan alternatif kalimat berbahasa Inggris dari #t.AMRtoTEXT dan translasi kembali dari kalimat berbahasa Indonesia.
Diagram alur untuk konstruksi Dataset Train dari AMR 3.0 dapat dilihat pada @fig--dataset-train-construction.

#fig-img(
  image("thesis-dataset-train.svg", width: 45%),
  caption: [Diagram alur untuk konstruksi Dataset Train dari AMR 3.0.],
) <fig--dataset-train-construction>

//~ Dataset Dev
Dataset AMR 3.0 bagian data validasi juga dibangun untuk tahap eksperimen.
Dataset tersebut dibangun dengan mentranslasi bagian kalimat berbahasa Inggris menjadi Bahasa Indonesia dengan menggunakan mesin translasi.
Hasil dari konstruksi dataset tersebut direferensikan dengan Dataset Dev.
Diagram alur untuk konstruksi Dataset Dev dapat dilihat pada @fig--dataset-dev-construction.

#fig-img(
  image("thesis-dataset-dev.svg", width: 50%),
  caption: [Diagram alur untuk konstruksi Dataset Dev dari AMR 3.0.],
) <fig--dataset-dev-construction>

//~ Dataset Test
Augmentasi data untuk konstruksi dataset berkualitas _gold_ mengambil bagian data uji dari AMR 2.0 yang direferensikan dengan Dataset Test.
Dataset AMR 2.0 digunakan supaya dapat hasil kinerja model dapat dikomparasikan dengan penelitian #icite("putra2022").
Bagian kalimat berbahasa Inggris dari data uji ditranslasi menjadi Bahasa Indonesia oleh ahli.
Hasil kalimat berbahasa Indonesia tersebut berkualitas _gold_ dan digunakan sebagai dataset test.
Diagram alur untuk konstruksi Dataset Test dari AMR 2.0 dapat dilihat pada @fig--dataset-test-construction.
Konstruksi dataset tersebut sudah dilakukan pada penelitian #icite("putra2022") dan akan digunakan langsung pada penelitian ini.

#fig-img(
  image("thesis-dataset-test.svg", width: 50%),
  caption: [Diagram alur untuk konstruksi Dataset Test dari AMR 2.0.],
) <fig--dataset-test-construction>

#let output-format = [`<g>`$g_1$`,..,`$g_m$`</g>`]

//~ Concatenation
Skema pelatihan yang digunakan dapat dilihat pada @fig--training-schema.
Pelatihan dicoba dengan konfigurasi dengan dan tanpa #t.concat.
Skema inferensi untuk konfigurasi tanpa #t.concat dapat dilihat pada @fig--inference-schema.
Input hanya berupa kalimat berbahasa Indonesia.
Skema inferensi untuk konfigurasi dengan #t.concat dapat dilihat pada @fig--inference-schema-concat.
Input berupa kalimat berbahasa Indonesia beserta hasil translasi ke Bahasa Inggris.

#fig-img(
  image("thesis-skema-training.svg", width: 40%),
  caption: [Skema pelatihan dengan tahap #t.gpretraining dan #t.finetuning.],
) <fig--training-schema>

#fig-img(
  image("thesis-inferensi.svg", width: 72%),
  caption: [Skema inferensi dengan konfigurasi bilingual.],
) <fig--inference-schema>

#fig-img(
  image("thesis-inferensi-concat.svg", width: 72%),
  caption: [Skema inferensi dengan konfigurasi #t.concat.],
) <fig--inference-schema-concat>

Pada konfigurasi tanpa #t.concat tetap mengikuti teknik pelatihan sebelumnya yang dapat dilihat pada @tab--pt-ft-strategies.
$t$/$g$ merupakan teks/graf _original_.
$accent(t, hat)$/$accent(g, hat)$ merupakan teks/graf yang _noisy_ (hasil #t.denoising).
$accent(t, macron)$/$accent(g, macron)$ merupakan teks/graf yang hilang.
Semua output dari pelatihan ini adalah bentuk graf yang utuh.
Sedangkan pada konfigurasi dengan #t.concat, diperlukan sedikit modifikasi untuk melakukan #t.gpretraining pada teknik AMRBART.

#let graphMasked = text(fill: rgb(0%, 33%, 0%).darken(20%))[`<g>`$g_1$`,..[mask]..,`$g_m$`</g>`]
#let graphBarMasked = text(fill: rgb(0%, 33%, 0%).darken(20%))[`<g>[mask]</g>`]
#let st(body) = text(fill: purple.darken(20%))[`<s>`#body`</s>`]
#let id(body) = text(fill: purple.darken(20%))[`<id>`#body]
#let en(body) = text(fill: blue.darken(50%))[`<en>`#body]
#let ot-colored = text(fill: red.darken(50%), output-format)
#let input-fmt(body) = text(size: 0.85em, body)

#fig-tab(
  tablex(
    columns: 3,
    align: (x, y) => if x <= 1 or y == 0 {center} else {left},
    [*Fase*],[*Input*],[*_Format_*],
    rowspanx(3)[G.P.T.],[$accent(t, macron) accent(g, hat)$],input-fmt[#st[`[mask]`]#graphMasked],
    (),[$t accent(g, hat)$],input-fmt[#st[$a_1$`,..,`$a_n$]#graphMasked],
    (),[$accent(t, hat) accent(g, hat)$],input-fmt[#st[$a_1$`,..[mask]..,`$a_n$]#graphMasked],
    [F.T.],[$t accent(g, macron)$],input-fmt[#st[$a_1$`,..,`$a_n$]#graphBarMasked],
    colspanx(2)[*_Output_*],(),input-fmt[#ot-colored],
  ),
  caption: [Format pada #t.gpretraining (G.P.T.) dan #t.finetuning (F.T.) untuk pelatihan graf model #t.amrparsing lintas bahasa pada skema pelatihan bilingual.],
) <tab--pt-ft-strategies>

Token `<s>` yang digunakan pada AMRBART diganti menjadi kode bahasa yang digunakan.
Bahasa Indonesia ditandai dengan _prefix_ token `<id>` dan Bahasa Inggris ditandai dengan _prefix_ token `<en>`.
Kalimat berbahasa Indonesia dan Inggris dilinearisasi secara sejajar sebagai input #t.gpretraining maupun #t.finetuning.
Strategi #t.gpretraining dan #t.finetuning untuk pelatihan graf model #t.amrparsing lintas bahasa tersebut dapat dilihat pada @tab--pt-ft-strategies-with-concat.
Output dari pelatihan tersebut merupakan graf @AMR yang dilinearisasi, yaitu #output-format, dan teks Bahasa Indonesia-nya.
Linearisasi graf menggunakan algoritma @DFS @bevilacqua2021.

#fig-tab(
  tablex(
    columns: 3,
    align: (x, y) => if x <= 1 or y == 0 {center} else {left},
    [*Fase*],[*Input*],[*_Format_*],
    rowspanx(7)[G.P.T.],[$accent(t, macron)_("ID") accent(t, macron)_("EN") accent(g, hat)$],input-fmt[#id[`[mask]`]#en[`[mask]`]#graphMasked],
    (),[$t_("ID") accent(t, macron)_("EN") accent(g, hat)$],input-fmt[#id[$a_1$`,..,`$a_(n_1)$]#en[`[mask]`]#graphMasked],
    (),[$accent(t, macron)_("ID") t_("EN") accent(g, hat)$],input-fmt[#id[`[mask]`]#en[$b_1$`,..,`$b_(n_2)$]#graphMasked],
    (),[$t_("ID") t_("EN") accent(g, hat)$],input-fmt[#id[$a_1$`,..,`$a_(n_1)$]#en[$b_1$`,..,`$b_(n_2)$]#graphMasked],
    (),[$t_("ID") accent(t, hat)_("EN") accent(g, hat)$],input-fmt[#id[$a_1$`,..,`$a_(n_1)$]#en[$b_1$`,..[mask]..,`$b_(n_2)$]#graphMasked],
    (),[$accent(t, hat)_("ID") t_("EN") accent(g, hat)$],input-fmt[#id[$a_1$`,..[mask]..,`$a_(n_1)$]#en[$b_1$`,..,`$b_(n_2)$]#graphMasked],
    (),[$accent(t, hat)_("ID") accent(t, hat)_("EN") accent(g, hat)$],input-fmt[#id[$a_1$`,..[mask]..,`$a_(n_1)$]#en[$b_1$`,..[mask]..,`$b_(n_2)$]#graphMasked],
    [F.T.],[$t_("ID") accent(t, macron)_("EN") accent(g, macron)$],input-fmt[#id[$a_1$`,..,`$a_(n_1)$]#en[$b_1$`,..,`$b_(n_2)$]#graphBarMasked],
    colspanx(2)[*_Output_*],(),input-fmt[#ot-colored],
  ),
  caption: [Format pada #t.gpretraining (G.P.T.) dan #t.finetuning (F.T.) untuk pelatihan graf model #t.amrparsing lintas bahasa pada skema pelatihan #t.concat.],
) <tab--pt-ft-strategies-with-concat>

Pada tahap #t.gpretraining dilakukan _masking_ secara dinamis ketika melakukan _training_ @bai2022.
Fungsi _noising_ dilakukan secara acak untuk melakukan _masking_ sebuah subgraf, 15% bagian untuk _masking_ simpul (konsep), dan/atau 15% untuk _masking_ sisi (relasi).
Sebuah subgraf minimal memiliki satu simpul dan satu sisi.
Setiap jenis _noising_ tersebut memiliki kemungkinan yang bertambah setiap _step_ pelatihan.
Nilai kemungkinan tersebut adalah $p = 0.1 + 0.75 dot.op t/T$.
Nilai $p$ merupakan kemungkinan dilakukan _noising_.
Nilai $t$ merupakan iterasi pelatihan dan $T$ merupakan iterasi maksimal.

//~ Evaluation
Metrik evaluasi yang digunakan adalah @SMATCH.
Evaluasi tersebut dilakukan dengan menghitung kemiripan graf @AMR hasil prediksi dan graf @AMR asli dari Dataset Test.
Model juga diuji dengan task #t.deop berdasarkan metrik @SMATCH dengan suatu _threshold_ sebagai batas antara label kelas parafrase dan bukan parafrase.

//~ Baseline Evaluation
Pendekatan _translate-and-parse_ @uhrig2021 digunakan sebagai _baseline_ pada penelitian ini.
Model mesin translasi yang digunakan adalah #t.opus-mt dan model #t.amrparsing yang digunakan adalah model dari penelitian #icite("zhang2019").
Tahapan yang dilakukan adalah melakukan translasi dari kalimat berbahasa Indonesia menjadi Bahasa Inggris, lalu dilakukan #t.amrparsing menjadi graf @AMR.
Hasil _baseline_ yang dibangun oleh #icite("putra2022") digunakan sebagai referensi.

Pengujian juga dilakukan dengan menguji kemampuan #t.amrparser dalam memformalisasi makna, dilakukan pengujian #t.deop, seperti yang dilakukan oleh #icite("putra2022").
Pengujian ini akan dilakukan pada dataset WReTE yang disediakan oleh IndoNLU @wilie2020.
Model _fine-tuned_ mBERT, IndoBERT-lite-large-p2, dan fastText-cc-id dari #icite("wilie2020") digunakan sebagai perbandingan dengan model #t.amrparser.
