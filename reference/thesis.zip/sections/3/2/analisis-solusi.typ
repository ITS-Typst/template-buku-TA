#import "/globals.typ": *

== Analisis Solusi

//~ Model Trimming
Model BART merupakan model berbasis Transformer yang terdiri dari _encoder_ dan _decoder_.
Input pada _encoder_ dan output pada _decoder_ memiliki bentuk berupa one-hot encoding setiap token yang ada pada kosa kata.
Semakin besar ukuran kosa kata, semakin banyak pula kalkulasi yang perlu dilakukan komputer ketika melakukan _training_ maupun inferensi.
#icite("srivastava2022") mengembangkan sebuah solusi dengan menghapus sebagian kosa kata yang tidak digunakan dari sebuah model berbasis Transformer tanpa mengurangi kinerjanya secara drastis.
Bagian _weight_ pada layer input dan _output_ dari bagian _encoder_ dan _decoder_ merupakan bagian yang dapat dihapus dengan bertujuan untuk mempercepat proses pelatihan dan inferensi.

//~ Dataset Augmentation
Terdapat dua aspek dari permasalahan dataset yang dapat diperbaiki dari penelitian #icite("putra2022"), yaitu jumlah dan kualitas dataset.
Pada #t.amrparsing lintas bahasa, _silver dataset_ diperlukan untuk membangun model #t.amrparsing lintas bahasa yang bisa didapatkan dari _gold dataset_ yang telah ada dalam Bahasa Inggris.
#icite("putra2022") telah membangun _silver dataset_ untuk Bahasa Indonesia dari dataset AMR 2.0 dan korpus paralel BPPT-PANL @bppt2009.
Jumlah _silver dataset_ dapat lebih diperbanyak dengan cara-cara berikut:
+ Menggunakan dataset AMR 3.0.
  Dataset AMR 3.0 memiliki sekitar 20,000 pasangan kalimat dan graf @AMR lebih banyak dibandingkan dengan Dataset AMR 2.0.

+ Menggunakan korpus paralel tambahan IWSLT17.
  #icite("putra2022") hanya menggunakan korpus paralel BPPT-PANL @bppt2009.
  Korpus paralel IWSLT17 @cettolo2017 dapat menambah sampai 107,329 pasang _silver dataset_.

+ Mengadopsi teknik augmentasi data oleh #icite("lee2022").
  Melakukan _parsing_ graf @AMR dari _gold dataset_ menjadi teks berbahasa Inggris, lalu dilakukan translasi ke Bahasa Indonesia.
  Teknik ini dapat menambah jumlah pasangan _silver dataset_ dari dataset AMR menjadi sampai maksimal dua kali lipat lebih banyak.

Peningkatan kualitas _silver dataset_ dapat dilakukan dengan menggunakan teknik augmentasi dataset dengan _ensemble_ oleh #icite("hoang2021").
Berdasarkan hasil penelitian #icite("lee2022"), teknik _ensemble_ dengan 5 model #t.amrparser dapat meningkatkan kualitas _silver dataset_ secara signifikan.

Kualitas _silver dataset_ dapat diukur dengan menghitung #t.cossim dari #t.multil _sentence embedding_ dari pasangan kalimat Bahasa Indonesia dan Bahasa Inggris @putra2022.
Model #t.mwordem yang digunakan untuk mendapatkan #t.multil _sentence embedding_ dari sebuah kalimat adalah @LABSE @feng2022.
Dalam meningkatkan kualitas _silver dataset_ tersebut, dapat dilakukan filtrasi untuk menghapus hasil translasi yang buruk.
Filtrasi dilakukan dengan mengaplikasikan algoritma @1-NN dengan #t.cossim sebagai nilai kedekatan antar kalimat berbahasa Inggris dan hasil translasinya.
Apabila hasil kalimat yang ditemukan dari @1-NN bukan merupakan kalimat awal sebelum translasi, maka pasangan kalimat tersebut tidak digunakan sebagai data pelatihan.

//~ Concatenation
Teknik #t.gpretraining oleh #icite("bai2022") yang menggunakan model bahasa BART terbukti dapat meningkatkan skor @SMATCH untuk #t.amrparsing.
Teknik tersebut belum dicoba untuk #t.amrparsing #t.linbhs.
Skema model pelatihan #t.amrparsing #t.linbhs telah diusulkan oleh #icite("blloshmi2020"), yaitu _zero-shot_, spesifik bahasa, dan bilingual.
Pada penelitian #icite("blloshmi2020"), ditunjukkan bahwa skema bilingual menghasilkan kinerja terbaik.
Teknik #t.gpretraining oleh #icite("bai2022") tersebut dapat dilakukan dengan skema pelatihan bilingual @blloshmi2020 untuk membangun model #t.linbhs untuk _task_ #t.amrparsing.
Pada skema bilingual, pasangan kalimat berbahasa Inggris dan Indonesia dianggap sebagai _instance_ data yang berbeda.
Mengadopsi teknik #t.pretraining @XLM, kalimat berbahasa Inggris dan Indonesia dapat dilakukan #t.concat menjadi satu _instance_ data.
