#let fn(
  title: [],
) = [
  Puji Syukur penulis panjatkan kepada Allah SWT, atas nikmat dan karunia-Nya, penulis dapat menyelesaikan tesis dengan judul "#title".
  Penulis menyadari selama proses penyusunan tesis, banyak pihak yang mendukung penyelesaian tesis ini.
  Oleh karena itu penulis ingin mengucapkan terima kasih kepada:

  + Ibu Dr. Masayu Leylia Khodra, S.T, M.T. selaku dosen pembimbing tesis penulis yang membantu dalam proses penulisan, penelitian, dan perbaikan terhadap tesis ini.
  + Bapak Ir. Rila Mandala, M.Eng., Ph.D dan Ibu Dr. Nur Ulfa Maulidevi, S.T, M.Sc. selaku dosen penguji sidang tesis yang telah memberikan banyak masukan untuk tesis saya.
  + Seluruh dosen, karyawan, dan staff program studi Magister Informatika ITB yang telah membantu proses pendidikan saya di Institut Teknologi Bandung baik secara langsung maupun tidak langsung.
  + Bapak Drs. H. Shokibul dan Ibu Dra. Hj. Marfuah selaku orang tua yang selalu memberikan dukungan dan doa selama penulis berkuliah di Sekolah Teknik Elektro dan Informatika ITB.
  + Semua pihak yang tidak dapat penulis rinci satu per satu yang telah membantu dalam proses penyusunan tesis ini.

  Penulis berharap penelitian ini dapat menjadi kontribusi dalam penelitian pemrosesan bahasa alami, terutama dalam bidang representasi semantik.
  Penulis juga menyadari bahwa terdapat kekurangan dalam penulisan dan pengerjaan tesis ini.
  Oleh karena itu penulis berharap mendapatkan saran dan kritik yang membangun untuk mengembangkan penelitian ini di masa depan.
]
