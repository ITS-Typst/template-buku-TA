#let terms = (
  "AMR": "Representasi yang memperhatikan semantik pada tingkat kalimat dalam bentuk struktur data graf berarah yang mempunyai akar",
  "Korpus paralel": "Kumpulan teks atau dokumen dalam dua atau lebih bahasa yang saling berhubungan secara paralel",
  "Parsing": ([_Parsing_], "Proses analisis dan penguraian suatu teks atau rangkaian simbol untuk mengidentifikasi struktur dan makna yang terkandung di dalamnya"),
  "Dataset": "Kumpulan data yang terorganisir dan terstruktur yang digunakan untuk analisis, penelitian, atau pengembangan model",
  "SMATCH": "Metode evaluasi yang digunakan dalam bidang pemrosesan bahasa alami untuk mengukur kualitas output dari sistem parsing semantik",
  "BLEU": "Metrik evaluasi yang digunakan dalam bidang pemrosesan bahasa alami untuk mengukur kualitas terjemahan mesin",
  "Preprocess": ([_Preprocess_], "Proses persiapan dan penyesuaian data sebelum diolah atau dianalisis lebih lanjut"),
  "Pre-training": ([_Pre-training_], "Proses pelatihan model dengan menggunakan dataset besar dan umum sebelum dilakukan fine-tuning atau penerapan pada tugas spesifik"),
  "Graph pre-training": ([_Graph pre-training_], [Proses _pre-training_ dengan teknik _masking_ pada graf input]),
  "Fine-tuning": ([_Fine-tuning_], "Proses mengambil model atau arsitektur yang telah dilatih sebelumnya dan menyesuaikannya dengan dataset atau tugas yang lebih spesifik"),
  "BART": [Model bahasa _sequence-to-sequence_ berbasis Transformer yang terdiri dari _bidirectional encoder_ dan _autoregressive decoder_],
  "Gold dataset": ([_Gold dataset_], [Dataset dengan kualitas dan kelengkapan yang lebih tinggi yang berasal dari sumber resmi dengan keandalan dan akurasi yang baik]),
  "Silver dataset": ([_Silver dataset_], [Dataset dengan kualitas dan validasi yang lebih rendah dibandingkan dengan _gold dataset_ yang berasal dari sumber yang lebih beragam dan kurang diverifikasi]),
)

#grid(
  columns: 2,
  gutter: 2em,
  ..terms.pairs().sorted(key: v => v.at(0)).map((v) => if type(v.at(1)) == "array" {([*#v.at(1).at(0)*], v.at(1).at(1))} else {([*#v.at(0)*], v.at(1))}).flatten()
)
